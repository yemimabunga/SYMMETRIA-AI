"""Independent differential-geometric and orbit validation."""
import numpy as np
import torch
from torch.func import vmap
from .geometry import killing_residual, local_frame, carter_tensor


def tensor_diagnostics(geometry,tensor_fn,x):
    r = vmap(lambda z:killing_residual(geometry,tensor_fn,z))(x).detach()
    k = vmap(tensor_fn)(x).detach()
    g, e = vmap(geometry.covariant)(x), vmap(lambda z:local_frame(geometry,z))(x)
    kl = g@k@g
    kframe = torch.einsum("nai,nij,nbj->nab",e,kl,e)
    rframe = torch.einsum("nai,nbj,nck,nijk->nabc",e,e,e,r)
    krms = kframe.square().mean((1,2)).sqrt().clamp_min(1e-14)
    rrms = rframe.square().mean((1,2,3)).sqrt()
    # Euclidean component norm IN A SPECIFIED ORTHONORMAL FRAME: positive,
    # but observer-dependent; not an indefinite Lorentz scalar norm.
    relative = geometry.mass*rrms/krms
    return {"coordinate_rms":float(r.square().mean().sqrt()),
            "frame_relative_rms":float(relative.square().mean().sqrt()),
            "frame_relative_max":float(relative.max()),
            "per_point":relative.numpy()}




def carter_error(model,x):
    learned = vmap(model.tensor)(x).detach()
    expected = vmap(lambda z:carter_tensor(model.geometry,z))(x).detach()
    return float((learned-expected).norm()/expected.norm())




class GaugedCandidate:
    """Same trivial-span projection and scale for baseline and neural comparisons."""
    def __init__(self,model,gauge):
        self.geometry=model.geometry
        self.source=model
        self.gauge_model=gauge

    def tensor_function(self):
        gauge=self.gauge_model
        raw=vmap(self.source.tensor)(gauge.gauge_x)
        coeff=gauge.gauge_pinv@(raw*gauge.gauge_weight).reshape(-1)
        residual=raw-torch.einsum('b,nbij->nij',coeff,gauge.gauge_trivial)
        norm=(residual*gauge.gauge_weight).square().mean().sqrt().clamp_min(1e-12)
        return lambda x:(self.source.tensor(x)-torch.einsum('b,bij->ij',coeff,gauge.trivial_tensors(x)))/norm

    def tensor(self,x):
        return self.tensor_function()(x)


def comparison_metrics(model,x,p,orbits):
    from .training import conservation_residual
    from .geodesics import invariant_values,drift
    fn=model.tensor_function() if hasattr(model,'tensor_function') else model.tensor
    raw,balanced=conservation_residual(model,x,p)
    diag=tensor_diagnostics(model.geometry,fn,x)
    diag.pop('per_point')
    heldout=[]
    for orbit in orbits:
        values=invariant_values(model.geometry,orbit,fn)
        q=values['Q']
        heldout.append({'terminated':orbit['terminated'],
                        'scaled_absolute_drift':drift(q),
                        'rms_relative_drift':float(np.max(abs(q-q[0]))/max(np.sqrt(np.mean(q*q)),1e-12))})
    return {'conservation_raw_rms':float(raw.detach().square().mean().sqrt()),
            'conservation_balanced_rms':float(balanced.detach().square().mean().sqrt()),
            'killing':diag,'heldout':heldout,
            'heldout_max_drift':max(d['scaled_absolute_drift'] for d in heldout),
            'heldout_max_rms_relative_drift':max(d['rms_relative_drift'] for d in heldout)}


def compare_carter_after_training(model,x,gauge):
    """Diagnostic only: sign-independent error after identical trivial gauge/scale."""
    class Reference:
        geometry=model.geometry
        def tensor(self,z):
            return carter_tensor(self.geometry,z)
    reference=GaugedCandidate(Reference(),gauge)
    a=vmap(model.tensor)(x).detach()
    b=vmap(reference.tensor)(x).detach()
    d=vmap(gauge.momentum_scale)(x)
    weight=d[:,:,None]*d[:,None,:]
    aa,bb=a*weight,b*weight
    return float(torch.minimum((aa-bb).norm(),(aa+bb).norm())/bb.norm())


