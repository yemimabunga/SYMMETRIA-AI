"""Trainable symmetric quadratic tensor ansatz; no Carter labels.

This deliberately small, linear physics-informed model is a transparent
baseline, not an unconstrained deep neural network or a universal search.
"""
import torch
from torch import nn
from torch.func import jacrev, vmap


class QuadraticInvariant(nn.Module):
    def __init__(self, geometry):
        super().__init__()
        self.geometry = geometry
        matrices, feature_ids, names = [], [], []
        features = ["1", "rho", "rho2", "cos2", "cot2"]
        for i in range(4):
            for j in range(i,4):
                for f,name in enumerate(features):
                    # Gauge out E², E*Lz and Lz². Constant multiple of g^{-1}
                    # (2H) is excluded by omitting its constant feature below.
                    if f == 0 and (i,j) in [(0,0),(0,3),(3,3)]:
                        continue
                    b = torch.zeros(4,4, dtype=torch.float64)
                    b[i,j], b[j,i] = 1.,1.
                    matrices.append(b)
                    feature_ids.append(f)
                    names.append(f"K{i}{j}*{name}")
        self.register_buffer("matrices",torch.stack(matrices))
        self.register_buffer("feature_ids",torch.tensor(feature_ids))
        self.names = names + ["g_inv*cos2", "g_inv*rho", "g_inv*rho2"]
        self.anchor = self.names.index("K22*1")
        free = [i for i in range(len(self.names)) if i != self.anchor]
        self.register_buffer("free",torch.tensor(free))
        self.weights = nn.Parameter(torch.zeros(len(free),dtype=torch.float64))

    def basis(self,x):
        rho = x[1]/(10*self.geometry.mass)
        c2, s2 = x[2].cos()**2, x[2].sin()**2
        f = torch.stack((rho*0+1,rho,rho*rho,c2,c2/s2))
        component_terms = self.matrices*f[self.feature_ids,None,None]
        metric_terms = torch.stack((c2,rho,rho*rho))[:,None,None]*self.geometry.inverse(x)
        return torch.cat((component_terms,metric_terms),dim=0)

    def coefficients(self):
        # c_anchor=1 blocks zero and fixes scale. It is an ansatz restriction:
        # it cannot detect invariants requiring a vanishing anchor coefficient.
        c = torch.zeros(len(self.names),dtype=self.weights.dtype,device=self.weights.device)
        c[self.anchor] = 1.
        return c.scatter(0,self.free,self.weights)

    def tensor(self,x):
        return torch.einsum("b,bij->ij",self.coefficients(),self.basis(x))

    def forward(self,x,p):
        return p @ self.tensor(x) @ p

    def reconstruct(self,x,p=None):
        """Independent reconstruction K^{ij} = (1/2) d²I/dp_i dp_j."""
        if p is None:
            p = torch.zeros_like(x)
        return 0.5*jacrev(jacrev(lambda q:self(x,q)))(p)


def conservation_design(model,x,p):
    """Each row evaluates {B_b^{ij}p_i p_j,H} for all basis tensors.

    This is the instantaneous conservation loss dI/dlambda, using exact
    Hamiltonian velocities, not noisy finite differences along an orbit.
    """
    geom = model.geometry
    b = vmap(model.basis)(x)
    db = vmap(jacrev(model.basis))(x)
    dx,dp = vmap(geom.flow)(x,p)
    design = (torch.einsum("nbijk,ni,nj,nk->nb",db,p,p,dx)
              + 2*torch.einsum("nbij,ni,nj->nb",b,p,dp))
    # Row balancing in a local approximate physical momentum scale.
    # It is positive and cannot turn a nonzero residual into an exact zero.
    scale = torch.stack((p[:,0],p[:,1],p[:,2]/x[:,1],
                         p[:,3]/(x[:,1]*x[:,2].sin())),dim=1)
    return design / scale.norm(dim=1).clamp_min(0.1)[:,None]**3


def fit(model,x,p):
    """Minimize mean({I,H}²) subject to fixed gauge and anchor.

    Because coefficients enter linearly, PyTorch's SVD least squares finds
    the global minimum directly. No label/supervised pretraining is used.
    This avoids pretending an unnecessary nonlinear optimizer is discovery.
    """
    design = conservation_design(model,x,p).detach()
    a, target = design[:,model.free], -design[:,model.anchor]
    scale = a.square().mean(0).sqrt().clamp_min(1e-14)
    balanced = a/scale
    initial = float((design@model.coefficients()).square().mean().detach())
    solution = torch.linalg.lstsq(balanced,target,rcond=1e-12,driver="gelsd")
    with torch.no_grad():
        model.weights.copy_(solution.solution/scale)
    final = float((design@model.coefficients()).square().mean().detach())
    sv = solution.singular_values
    return {"initial_loss":initial,"final_loss":final,
            "free_parameters":len(model.free),"rank":int(solution.rank),
            "singular_values":sv.tolist(),
            "condition_number":float(sv[0]/sv[-1]),
            "samples":len(x)}
