"""SYMMETRIA-AI: neural tensor search with a preserved physics baseline."""
