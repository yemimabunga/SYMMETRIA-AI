"""Final optimization: cached geometry, balanced physical losses, no Carter labels.

The training Killing operator uses symmetric cubic Hamiltonian coefficients.
Independent verification continues to use covariant derivatives/Christoffels
in geometry.py, which is unchanged.
"""
import copy
import time
import numpy as np
import torch
from torch.func import jacrev,jacfwd,vmap
from .geometry import local_frame
from .geodesics import initial_state,integrate
from .training import flow_data


class PhysicsBatch:
    def __init__(self,model,x,p):
        if x.dtype != torch.float64 or p.dtype != torch.float64:
            raise TypeError('Physical loss data must be float64')
        g=model.geometry
        self.x,self.p=x,p
        self.gi=vmap(g.inverse)(x).detach()
        self.dgi=vmap(jacrev(g.inverse))(x).detach()
        gcov=vmap(g.covariant)(x)
        e=vmap(lambda z:local_frame(g,z))(x)
        self.lowerframe=(e@gcov).detach()
        self.trivial=vmap(model.trivial_tensors)(x).detach()
        self.dtrivial=vmap(jacrev(model.trivial_tensors))(x).detach()
        self.dx,self.dp,self.scale=flow_data(g,x,p)

    def subset(self,ids):
        batch=object.__new__(PhysicsBatch)
        for key,value in vars(self).items():
            setattr(batch,key,value[ids])
        return batch


def cached_tensor(model,batch):
    coeff,norm=model.gauge()
    raw=vmap(model.raw_tensor)(batch.x)
    deriv=vmap(jacrev(model.raw_tensor))(batch.x)
    k=(raw-torch.einsum('b,nbij->nij',coeff,batch.trivial))/norm
    dk=(deriv-torch.einsum('b,nbijk->nijk',coeff,batch.dtrivial))/norm
    return k,dk


def frame_residual(k,dk,batch):
    # dI/dlambda = A^{ijk} p_i p_j p_k; symmetrize its three slots.
    a=(torch.einsum('nija,nak->nijk',dk,batch.gi)
       -torch.einsum('nak,nija->nijk',k,batch.dgi))
    sym=(a+a.permute(0,2,3,1)+a.permute(0,3,1,2))/3
    w=batch.lowerframe
    return torch.einsum('nai,nbj,nck,nijk->nabc',w,w,w,sym)


def physical_terms(model,batch):
    k,dk=cached_tensor(model,batch)
    p=batch.p
    raw=(torch.einsum('nijk,ni,nj,nk->n',dk,p,p,batch.dx)
         +2*torch.einsum('nij,ni,nj->n',k,p,batch.dp))
    cons=(raw/batch.scale**3).square().mean()
    residual=frame_residual(k,dk,batch)
    killing=residual.square().mean()*model.geometry.mass**2
    return cons,killing


def optimize(model,x,p,*,steps=1500,lbfgs_steps=1000,batch_size=128,
             lr=.002,seed=0,geometry_loss=True,normalize_loss=True,callback=None):
    """Frozen initial-loss normalization. Hard nontriviality; no soft penalty.

    Callback gets the Adam endpoint for a paired optimizer ablation. No
    validation data or Carter information is passed to this function.
    """
    start=time.perf_counter()
    data=PhysicsBatch(model,x,p)
    if float(model.gauge()[1].detach())<=1e-10:
        raise ValueError('Degenerate neural candidate')
    with torch.no_grad():
        initial=physical_terms(model,data)
    denominators=[float(v) if normalize_loss else 1. for v in initial]
    denominators=[max(v,1e-30) for v in denominators]
    history=[]
    def terms(batch):
        cons,killing=physical_terms(model,batch)
        total=cons/denominators[0]
        if geometry_loss:
            total=total+killing/denominators[1]
        return cons,killing,total
    def log(stage,step):
        with torch.no_grad():
            c,k,t=terms(data)
        record={'stage':stage,'step':step,'conservation':float(c),'killing':float(k),
                'nontriviality':0.,'regularization':0.,'total':float(t),
                'weighted_conservation':float(c)/denominators[0],
                'weighted_killing':float(k)/denominators[1] if geometry_loss else 0.}
        history.append(record)
        print(f'  {stage} {step}: cons={float(c):.3e}, Killing={float(k):.3e}, total={float(t):.3e}',flush=True)
    log('initial',0)
    opt=torch.optim.Adam(model.parameters(),lr=lr)
    rng=torch.Generator().manual_seed(seed)
    for i in range(steps):
        ids=torch.randperm(len(x),generator=rng)[:min(batch_size,len(x))]
        opt.zero_grad()
        c,k,total=terms(data.subset(ids))
        if not bool(torch.isfinite(total)):
            raise FloatingPointError('Nonfinite optimization loss')
        total.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),10.)
        opt.step()
        if (i+1)%500==0 or i==steps-1:
            log('adam',i+1)
    adam_state=copy.deepcopy(model.state_dict())
    if callback is not None:
        callback(model)
    evaluations=0
    # Chunking logs accepted endpoints, not rejected line-search trials.
    opt=torch.optim.LBFGS(model.parameters(),lr=1.,max_iter=min(50,lbfgs_steps),
                         tolerance_grad=1e-13,tolerance_change=1e-16,
                         history_size=80,line_search_fn='strong_wolfe')
    remaining=lbfgs_steps;iterations=0
    while remaining>0:
        budget=min(50,remaining);opt.param_groups[0]['max_iter']=budget
        before=opt.state.get(next(iter(model.parameters())),{}).get('n_iter',0)
        def closure():
            nonlocal evaluations
            opt.zero_grad();c,k,t=terms(data)
            if not bool(torch.isfinite(t)):
                raise FloatingPointError('Nonfinite L-BFGS loss')
            t.backward();evaluations+=1
            return t
        opt.step(closure)
        after=opt.state[next(iter(model.parameters()))].get('n_iter',0)
        used=after-before;iterations+=used;remaining-=budget
        log('lbfgs',iterations)
        if used<budget:
            break
    if float(model.gauge()[1].detach())<=1e-10:
        raise ValueError('Degenerate neural candidate')
    return {'initial_conservation':float(initial[0]),'initial_killing':float(initial[1]),
            'denominators':denominators,'geometry_loss':geometry_loss,
            'normalized_loss':normalize_loss,'history':history,'adam_steps':steps,
            'lbfgs_budget':lbfgs_steps,'lbfgs_iterations':iterations,
            'lbfgs_evaluations':evaluations,'seconds':time.perf_counter()-start,
            'final_conservation':history[-1]['conservation'],
            'final_killing':history[-1]['killing'],
            'nontriviality':'hard projection and unit gauge norm; zero soft penalty',
            'regularization':'none; zero soft penalty'},adam_state


def diverse_orbits(geometry,count,seed,duration=60.):
    """Stratify a pool made with the original Hamiltonian-constrained sampler.

    No new orbit integrator or different mass-shell solver is introduced.
    Farthest-point initial-condition coverage, independent of candidate error.
    """
    rng=np.random.default_rng(seed)
    pool=[initial_state(geometry,rng) for _ in range(max(64,16*count))]
    y=np.stack(pool)
    features=y[:,[1,2,4,5,6,7]]
    z=(features-features.mean(0))/features.std(0).clip(1e-12)
    selected=[];attempted=[];accepted=[]
    while len(accepted)<count and len(attempted)<len(pool):
        if not selected:
            candidate=next(i for i in range(len(pool)) if i not in attempted)
        else:
            dist=((z[:,None,:]-z[selected][None,:,:])**2).sum(-1).min(1)
            dist[attempted]=-1
            candidate=int(dist.argmax())
        attempted.append(candidate)
        orbit=integrate(geometry,pool[candidate],duration=duration)
        states=orbit['states']
        inside=((states[:,1]>=6*geometry.mass)&(states[:,1]<=14*geometry.mass)
                &(states[:,2]>=.65)&(states[:,2]<=np.pi-.65)).all()
        if not orbit['terminated'] and inside:
            selected.append(candidate);accepted.append(orbit)
    if len(accepted)<count:
        raise RuntimeError('Insufficient complete in-domain orbits; do not silently truncate')
    for orbit in accepted:
        orbit['sampling_attempts']=len(attempted)
    return accepted


def polish_output_layer(model,x,p,*,geometry_loss=True,rcond=1e-8,denominators=None):
    """Unsupervised linear-head refinement inside the existing trained MLP.

    Hidden weights stay fixed. Solve min ||A w|| with ||B w||=1, where A
    contains physical residuals and B is the trivial-projected gauge map.
    Truncated SVD handles near-dependent hidden features. No Carter input.
    """
    import scipy.linalg
    start=time.perf_counter()
    def basis(z):
        angular_scale=(torch.pi/2-.65) if model.normalized_inputs else 1.
        inp=torch.stack(((z[1]/model.geometry.mass-10.)/4.,(z[2]-torch.pi/2)/angular_scale))
        hidden=model.net[:-1](inp)
        hidden=torch.cat((hidden,hidden.new_ones(1)))
        if model.output_scaling=='local':
            d=model.momentum_scale(z)
        else:
            one=z[1]*0+1;d=torch.stack((one,one,one*10*model.geometry.mass,one*10*model.geometry.mass))
        return (model.symmetric_basis[:,None]*hidden[None,:,None,None]/(d[None,None,:,None]*d[None,None,None,:])).reshape(-1,4,4)
    with torch.no_grad():
        bg=vmap(basis)(model.gauge_x)
        weighted=(bg*model.gauge_weight[:,None]).permute(0,2,3,1).reshape(-1,bg.shape[1])
        projection=model.gauge_pinv@weighted
        bg=bg-torch.einsum('ab,naij->nbij',projection,model.gauge_trivial)
        b=(bg*model.gauge_weight[:,None]).permute(0,2,3,1).reshape(-1,bg.shape[1]).numpy()
        _,s,vh=scipy.linalg.svd(b,full_matrices=False,lapack_driver='gesvd')
        keep=s>s[0]*rcond
        transform=vh[keep].T/s[keep][None,:]
        matrices=[]
        n=len(x)
        if denominators is None:
            vals=physical_terms(model,PhysicsBatch(model,x,p))
            denominators=[max(float(t),1e-30) for t in vals]
        for offset in range(0,n,64):
            batch=PhysicsBatch(model,x[offset:offset+64],p[offset:offset+64])
            kb=vmap(basis)(batch.x)-torch.einsum('ab,naij->nbij',projection,batch.trivial)
            dkb=vmap(jacfwd(basis))(batch.x)-torch.einsum('ab,naijk->nbijk',projection,batch.dtrivial)
            pp=batch.p
            ac=(torch.einsum('nbijk,ni,nj,nk->nb',dkb,pp,pp,batch.dx)
                +2*torch.einsum('nbij,ni,nj->nb',kb,pp,batch.dp))/batch.scale[:,None]**3
            matrices.append((ac.numpy()@transform)/np.sqrt(n*denominators[0]))
            if geometry_loss:
                a=(torch.einsum('nbija,nak->nbijk',dkb,batch.gi)
                   -torch.einsum('nbak,nija->nbijk',kb,batch.dgi))
                sym=(a+a.permute(0,1,3,4,2)+a.permute(0,1,4,2,3))/3
                w=batch.lowerframe
                frame=torch.einsum('nai,ncj,ndk,nbijk->nbacd',w,w,w,sym)
                mat=frame.permute(0,2,3,4,1).reshape(-1,kb.shape[1]).numpy()
                matrices.append((mat@transform)*model.geometry.mass/np.sqrt(n*64*denominators[1]))
        a=np.concatenate(matrices)
        _,residual_s,vha=scipy.linalg.svd(a,full_matrices=False,lapack_driver='gesvd')
        weights=transform@vha[-1]
        weights*=np.sqrt(b.shape[0])
        weights=weights.reshape(10,-1)
        model.net[-1].weight.copy_(torch.tensor(weights[:,:-1]))
        model.net[-1].bias.copy_(torch.tensor(weights[:,-1]))
    return {'method':'SVD physical residual refinement of existing linear output layer',
            'geometry_loss':geometry_loss,'gauge_rcond':rcond,'retained_rank':int(keep.sum()),
            'head_parameters':int(len(s)),'largest_output_weight':float(np.abs(weights).max()),
            'retained_gauge_condition':float(s[0]/s[keep][-1]),'gauge_singular_values':s.tolist(),
            'physical_singular_values':residual_s.tolist(),'denominators':denominators,
            'seconds':time.perf_counter()-start}
