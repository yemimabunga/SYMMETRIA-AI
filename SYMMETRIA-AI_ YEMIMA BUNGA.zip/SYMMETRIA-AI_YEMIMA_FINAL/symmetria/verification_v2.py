"""Matched deformation verification for frozen SYMMETRIA-AI checkpoints.

This module does not train or select models.  It evaluates already-frozen
``full`` checkpoints on held-out geodesics matched across epsilon and on one
common set of off-orbit verification points.  A fixed Kerr Killing tensor is
carried unchanged into each deformed geometry as a physically transparent
comparator.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean, median, stdev

import numpy as np
import torch

from .ai_model import NeuralInvariant
from .diagnostics import tensor_diagnostics, compare_carter_after_training
from .geodesics import collocation, invariant_values, drift, matched_orbits
from .geometry import Geometry, carter_tensor


def _save_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


class FixedKerrTensor:
    """The same Kerr tensor function evaluated in any target geometry.

    ``reference_geometry`` always has epsilon=0.  ``geometry`` is only the
    geometry in which the tensor is being verified; it never changes the
    tensor itself.
    """

    def __init__(self, evaluation_geometry: Geometry, *, mass=1.0, spin=0.6):
        self.geometry = evaluation_geometry
        self.reference_geometry = Geometry(mass=mass, spin=spin, epsilon=0.0)

    def tensor(self, x):
        return carter_tensor(self.reference_geometry, x)


def _eps_name(eps: float) -> str:
    return f"epsilon_{eps:g}"


def load_full_checkpoint(source: Path, eps: float, seed: int) -> NeuralInvariant:
    path = source / _eps_name(eps) / f"seed_{seed}" / "full.pt"
    if not path.exists():
        raise FileNotFoundError(f"Missing frozen full checkpoint: {path}")
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    geometry_data = checkpoint.get("geometry", {})
    geometry = Geometry(**geometry_data) if geometry_data else Geometry(epsilon=eps)
    if abs(geometry.epsilon - eps) > 1e-15:
        raise ValueError(f"Checkpoint epsilon {geometry.epsilon} != requested {eps}")
    model = NeuralInvariant(
        geometry,
        width=checkpoint.get("width", 24),
        output_scaling=checkpoint.get("output_scaling", "local"),
    )
    model.load_state_dict(checkpoint["state_dict"])
    model.eval()
    return model


def _metrics(geometry: Geometry, tensor_fn, verify_x: torch.Tensor, orbits) -> dict:
    diag = tensor_diagnostics(geometry, tensor_fn, verify_x)
    per_orbit = []
    for i, orbit in enumerate(orbits):
        values = invariant_values(geometry, orbit, tensor_fn)["Q"]
        per_orbit.append({
            "orbit": i,
            "delta_I": drift(values),
            "rms_relative_drift": float(
                np.max(np.abs(values-values[0])) /
                max(np.sqrt(np.mean(values*values)), 1e-12)
            ),
        })
    return {
        "R_K": diag["frame_relative_rms"],
        "R_K_max": diag["frame_relative_max"],
        "delta_I": max(item["delta_I"] for item in per_orbit),
        "rms_relative_drift_max": max(item["rms_relative_drift"] for item in per_orbit),
        "per_orbit": per_orbit,
    }


def build_matched_data(epsilons, *, count=8, seed=65000, duration=60., samples=160):
    geometries = [Geometry(epsilon=e) for e in epsilons]
    return matched_orbits(
        geometries, count=count, seed=seed, duration=duration,
        samples=samples,
    )


def save_matched_data(path: Path, epsilons, matched) -> None:
    arrays = {"skeletons": matched["skeletons"]}
    for eps, orbits in zip(epsilons, matched["orbits"]):
        prefix = _eps_name(eps)
        for i, orbit in enumerate(orbits):
            arrays[f"{prefix}_orbit_{i}"] = orbit["states"]
            arrays[f"{prefix}_tau_{i}"] = orbit["tau"]
    np.savez_compressed(path, **arrays)


def _write_csv(path: Path, rows, fieldnames) -> None:
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def evaluate(source: Path, out: Path, epsilons, seeds, *, heldout_count=8,
             orbit_seed=65000, verify_seed=64000, duration=60., samples=160):
    out.mkdir(parents=True, exist_ok=True)
    verify_x, verify_p = collocation(512, verify_seed)
    matched = build_matched_data(
        epsilons, count=heldout_count, seed=orbit_seed,
        duration=duration, samples=samples,
    )
    save_matched_data(out / "matched_verification_data.npz", epsilons, matched)
    _save_json(out / "verification_manifest.json", {
        "epsilons": list(epsilons),
        "seeds": list(seeds),
        "heldout_count": heldout_count,
        "matched_orbit_seed": orbit_seed,
        "common_verification_seed": verify_seed,
        "verification_points": len(verify_x),
        "duration": duration,
        "samples_per_orbit": samples,
        "matched_sampling_attempts": matched["attempts"],
        "construction": (
            "same (t,r,theta,phi,p_r,p_theta,p_phi) skeleton at every epsilon; "
            "p_t re-solved from the unit-mass timelike mass shell"
        ),
        "selection": "complete in-domain orbit segment at every epsilon; model metrics never used",
        "fixed_kerr": "epsilon=0 Kerr Killing tensor carried unchanged; no refit or optimization",
    })

    detail = []
    kerr_rows = []
    for eps_index, eps in enumerate(epsilons):
        geometry = Geometry(epsilon=eps)
        orbits = matched["orbits"][eps_index]
        fixed = FixedKerrTensor(geometry, mass=geometry.mass, spin=geometry.spin)
        fixed_metrics = _metrics(geometry, fixed.tensor, verify_x, orbits)
        detail.append({
            "epsilon": eps,
            "seed": None,
            "method": "FIXED_KERR",
            **fixed_metrics,
        })
        for seed in seeds:
            model = load_full_checkpoint(source, eps, seed)
            metrics = _metrics(geometry, model.tensor, verify_x, orbits)
            row = {
                "epsilon": eps,
                "seed": seed,
                "method": "SYMMETRIA_AI",
                **metrics,
            }
            detail.append(row)
            if eps == 0:
                tensor_error = compare_carter_after_training(model, verify_x, model)
                kerr_rows.append({
                    "seed": seed,
                    "tensor_error": tensor_error,
                    "R_K": metrics["R_K"],
                    "delta_I": metrics["delta_I"],
                })

    flat = []
    for row in detail:
        flat.append({
            "epsilon": row["epsilon"],
            "seed": "" if row["seed"] is None else row["seed"],
            "method": row["method"],
            "R_K": row["R_K"],
            "delta_I": row["delta_I"],
            "R_K_max": row["R_K_max"],
            "rms_relative_drift_max": row["rms_relative_drift_max"],
            "convergence": "frozen_checkpoint" if row["method"] == "SYMMETRIA_AI" else "not_applicable",
        })
    _write_csv(
        out / "deformation_sweep.csv", flat,
        ["epsilon", "seed", "method", "R_K", "delta_I", "R_K_max",
         "rms_relative_drift_max", "convergence"],
    )
    _write_csv(out / "kerr_benchmark.csv", kerr_rows,
               ["seed", "tensor_error", "R_K", "delta_I"])

    summary = []
    for eps in epsilons:
        for method in ["SYMMETRIA_AI", "FIXED_KERR"]:
            rows = [r for r in flat if r["epsilon"] == eps and r["method"] == method]
            for metric in ["R_K", "delta_I"]:
                vals = [float(r[metric]) for r in rows]
                summary.append({
                    "epsilon": eps,
                    "method": method,
                    "metric": metric,
                    "mean": mean(vals),
                    "sd": stdev(vals) if len(vals) > 1 else 0.0,
                    "median": median(vals),
                    "min": min(vals),
                    "max": max(vals),
                    "n": len(vals),
                })
    _write_csv(out / "final_summary.csv", summary,
               ["epsilon", "method", "metric", "mean", "sd", "median", "min", "max", "n"])
    _save_json(out / "detailed_metrics.json", detail)
    return detail, kerr_rows, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("checkpoints"),
                        help="Frozen checkpoint tree included with the submission")
    parser.add_argument("--out", type=Path, default=Path("verification_v2"))
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--eps", type=float, nargs="+", default=[0, .01, .02, .05, .1])
    parser.add_argument("--heldout-count", type=int, default=8)
    parser.add_argument("--orbit-seed", type=int, default=65000)
    parser.add_argument("--verify-seed", type=int, default=64000)
    parser.add_argument("--duration", type=float, default=60.)
    parser.add_argument("--samples", type=int, default=160)
    args = parser.parse_args()
    if args.out.exists() and any(args.out.iterdir()):
        parser.error("Use an empty/new output folder to preserve previous verification.")
    if not args.seeds or not args.eps or args.heldout_count < 1:
        parser.error("Need at least one seed, epsilon, and held-out orbit.")
    torch.set_default_dtype(torch.float64)
    torch.set_num_threads(1)
    evaluate(
        args.source, args.out, args.eps, args.seeds,
        heldout_count=args.heldout_count,
        orbit_seed=args.orbit_seed,
        verify_seed=args.verify_seed,
        duration=args.duration,
        samples=args.samples,
    )
    print("Completed matched verification:", args.out, flush=True)


if __name__ == "__main__":
    main()
