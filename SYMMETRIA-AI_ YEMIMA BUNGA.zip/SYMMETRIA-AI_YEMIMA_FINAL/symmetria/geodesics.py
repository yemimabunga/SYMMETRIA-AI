"""Independent orbit integration using Hamilton's equations and DOP853."""
import numpy as np
import torch
from torch.func import vmap
from scipy.integrate import solve_ivp


def initial_state(geometry, rng):
    """Diverse inclined, unit-mass timelike initial data; solve for p_t."""
    x = np.array([0., rng.uniform(8.,12.)*geometry.mass,
                  rng.uniform(0.9,2.2), 0.])
    p = np.array([0., rng.uniform(-0.025,0.025),
                  rng.uniform(-1.4,1.4)*geometry.mass,
                  rng.uniform(2.9,3.8)*geometry.mass])
    gi = geometry.inverse(torch.tensor(x)).detach().numpy()
    aa, bb = gi[0,0], 2*gi[0,3]*p[3]
    cc = 1 + p[1:] @ gi[1:,1:] @ p[1:]
    disc = bb*bb-4*aa*cc
    if disc <= 0:
        raise ValueError("No real timelike initial p_t.")
    p[0] = (-bb + np.sqrt(disc))/(2*aa)
    if (gi@p)[0] <= 0:
        raise ValueError("Initial orbit is not future directed.")
    return np.r_[x,p]


def initial_skeleton(rng, mass=1.):
    """Geometry-independent initial data except for ``p_t``.

    The same spatial position and spatial canonical momenta can therefore be
    mapped onto several geometries by solving the timelike mass-shell
    condition separately in each geometry.  This is used only for matched
    held-out verification, not for training-data selection.
    """
    x = np.array([0., rng.uniform(8.,12.)*mass,
                  rng.uniform(0.9,2.2), 0.])
    p_spatial = np.array([rng.uniform(-0.025,0.025),
                          rng.uniform(-1.4,1.4)*mass,
                          rng.uniform(2.9,3.8)*mass])
    return np.r_[x, p_spatial]


def state_from_skeleton(geometry, skeleton):
    """Solve ``p_t`` for a shared held-out initial-condition skeleton.

    ``skeleton`` stores ``(t,r,theta,phi,p_r,p_theta,p_phi)``.  The returned
    state is unit-mass timelike and future directed in ``geometry``.  No model
    prediction enters this construction.
    """
    skeleton = np.asarray(skeleton, dtype=float)
    if skeleton.shape != (7,):
        raise ValueError("Matched-orbit skeleton must have seven entries.")
    x = skeleton[:4].copy()
    p = np.r_[0., skeleton[4:]].astype(float)
    gi = geometry.inverse(torch.tensor(x)).detach().numpy()
    aa, bb = gi[0,0], 2*gi[0,3]*p[3]
    cc = 1 + p[1:] @ gi[1:,1:] @ p[1:]
    disc = bb*bb - 4*aa*cc
    if disc <= 0:
        raise ValueError("No real timelike initial p_t for matched orbit.")
    roots = [(-bb + np.sqrt(disc))/(2*aa),
             (-bb - np.sqrt(disc))/(2*aa)]
    for root in roots:
        q = p.copy(); q[0] = root
        if (gi @ q)[0] > 0:
            return np.r_[x, q]
    raise ValueError("Matched orbit is not future directed.")


def matched_orbits(geometries, count, seed, duration=60., samples=160,
                   max_attempts=512):
    """Construct held-out orbit families matched across several geometries.

    Candidate initial conditions are generated without reference to any
    learned tensor.  A candidate is accepted only when the corresponding
    orbit segment is complete and stays inside the common numerical domain
    for *every* geometry.  This makes deformation comparisons use the same
    spatial initial conditions and spatial canonical momenta; only ``p_t`` is
    re-solved to satisfy the mass shell in each metric.
    """
    geometries = list(geometries)
    if not geometries:
        raise ValueError("At least one geometry is required.")
    masses = [g.mass for g in geometries]
    if not np.allclose(masses, masses[0]):
        raise ValueError("Matched-orbit geometries must share the same mass.")
    rng = np.random.default_rng(seed)
    accepted_skeletons = []
    accepted = [[] for _ in geometries]
    attempts = 0
    while len(accepted_skeletons) < count and attempts < max_attempts:
        attempts += 1
        skeleton = initial_skeleton(rng, masses[0])
        family = []
        valid = True
        try:
            for geometry in geometries:
                y0 = state_from_skeleton(geometry, skeleton)
                orbit = integrate(geometry, y0, duration=duration, samples=samples)
                states = orbit['states']
                inside = ((states[:,1] >= 6*geometry.mass)
                          & (states[:,1] <= 14*geometry.mass)
                          & (states[:,2] >= .65)
                          & (states[:,2] <= np.pi-.65)).all()
                if orbit['terminated'] or not inside:
                    valid = False
                    break
                family.append(orbit)
        except (ValueError, RuntimeError, FloatingPointError):
            valid = False
        if valid:
            accepted_skeletons.append(skeleton)
            for bucket, orbit in zip(accepted, family):
                orbit['matched_skeleton'] = skeleton.copy()
                orbit['sampling_attempts'] = attempts
                bucket.append(orbit)
    if len(accepted_skeletons) < count:
        raise RuntimeError(
            f"Only {len(accepted_skeletons)} matched complete orbits found "
            f"after {attempts} attempts; do not silently truncate.")
    return {
        'skeletons': np.stack(accepted_skeletons),
        'orbits': accepted,
        'attempts': attempts,
        'seed': seed,
    }


def integrate(geometry, y0, duration=120., samples=160, rtol=1e-10, atol=1e-12):
    def rhs(t, y):
        x, p = torch.tensor(y[:4]), torch.tensor(y[4:])
        dx, dp = geometry.flow(x,p)
        return torch.cat((dx,dp)).detach().numpy()
    def boundary(t,y):
        return min(y[1]-geometry.cutoff, y[2]-0.12, np.pi-0.12-y[2])
    boundary.terminal, boundary.direction = True, -1
    sol = solve_ivp(rhs, (0,duration), y0, method="DOP853",
                    t_eval=np.linspace(0,duration,samples),
                    events=boundary, rtol=rtol, atol=atol, max_step=3.)
    if not sol.success:
        raise RuntimeError(sol.message)
    if len(sol.t) < 10:
        raise RuntimeError("Orbit stopped before 10 samples; choose safer data.")
    return {"tau":sol.t, "states":sol.y.T, "terminated":bool(sol.status == 1)}




def collocation(count, seed, mass=1.):
    """Off-shell probes prevent learning an invariant of just one mass shell.

    p_theta and p_phi have length units; random probes cover all components.
    These probes are NOT advertised as physical unit-mass trajectories.
    """
    rng = np.random.default_rng(seed)
    x = np.zeros((count,4))
    x[:,1] = rng.uniform(6,14,count)*mass
    x[:,2] = rng.uniform(0.65,np.pi-0.65,count)
    p = rng.normal(size=(count,4))
    p[:,2] *= x[:,1]
    p[:,3] *= x[:,1]*np.sin(x[:,2])
    return torch.tensor(x), torch.tensor(p)


def invariant_values(geometry, orbit, tensor_fn):
    y = torch.tensor(orbit["states"])
    x,p = y[:,:4],y[:,4:]
    with torch.no_grad():
        h = vmap(geometry.hamiltonian)(x,p)
        q = torch.einsum("ni,nij,nj->n",p,vmap(tensor_fn)(x),p)
    return {"H":h.numpy(),"E":-p[:,0].numpy(),"Lz":p[:,3].numpy(),"Q":q.numpy()}


def drift(values):
    """Absolute change / max(1, |initial value|); safe near zero."""
    return float(np.max(np.abs(values-values[0]))/max(1.,abs(values[0])))
