"""Reproducible optimization/ablation suite; independent final test data."""
import argparse
import copy
import json
from dataclasses import asdict
from pathlib import Path
import time
import numpy as np
import torch
from torch.func import vmap
from .geometry import Geometry,carter_tensor
from .geodesics import collocation,invariant_values
from .ai_model import NeuralInvariant
from .legacy_ai_model import NeuralInvariant as LegacyNeural
from .legacy_training import train_neural
from .baseline_model import QuadraticInvariant,fit
from .optimization import optimize,diverse_orbits,polish_output_layer,PhysicsBatch,physical_terms
from .training import conservation_residual
from .diagnostics import comparison_metrics,compare_carter_after_training,GaugedCandidate


def save_json(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


class CarterReference:
    def __init__(self,g): self.geometry=g
    def tensor(self,x): return carter_tensor(self.geometry,x)


class RandomTensor:
    def __init__(self,g,seed):
        self.geometry=g
        rng=torch.Generator().manual_seed(seed)
        a=torch.randn(4,4,generator=rng,dtype=torch.float64)
        self.value=(a+a.T)/2
    def tensor(self,x): return self.value+x[1]*0


def dataset(g,stage,out):
    base=17000 if stage=='development' else 61000
    train=diverse_orbits(g,6,base,duration=60.)
    heldout=diverse_orbits(g,4,base+1000,duration=60.)
    xc,pc=collocation(768,base+2000)
    y=np.concatenate([o['states'][::4] for o in train])
    x=torch.cat((xc,torch.tensor(y[:,:4])))
    p=torch.cat((pc,torch.tensor(y[:,4:])))
    xv,pv=collocation(512,base+3000)
    # Final points are used only downstream of training; not adaptive training.
    arrays={'train_x':x.numpy(),'train_p':p.numpy(),'verify_x':xv.numpy(),'verify_p':pv.numpy()}
    for group,orbits in [('train',train),('heldout',heldout)]:
        for i,o in enumerate(orbits):
            arrays[f'{group}_{i}']=o['states'];arrays[f'{group}_tau_{i}']=o['tau']
    np.savez_compressed(out/'data.npz',**arrays)
    initial=np.stack([o['states'][0] for o in train])
    save_json(out/'data_manifest.json',{'stage':stage,'train_orbit_seed':base,
        'test_orbit_seed':base+1000,'train_collocation_seed':base+2000,
        'verify_seed':base+3000,'train_points':len(x),'verify_points':len(xv),
        'training_orbits':len(train),'heldout_orbits':len(heldout),
        'train_initial_states':initial.tolist(),
        'sampling_attempts_train':train[0].get('sampling_attempts'),
        'sampling_attempts_test':heldout[0].get('sampling_attempts'),
        'train_terminated':[o['terminated'] for o in train],
        'test_terminated':[o['terminated'] for o in heldout]})
    return x,p,xv,pv,train,heldout


def measure(model,x,p,xv,pv,heldout,gauge,epsilon):
    result=comparison_metrics(model,xv,pv,heldout)
    raw,balanced=conservation_residual(model,x,p)
    result['training_conservation_rms']=float(balanced.detach().square().mean().sqrt())
    result['training_conservation_raw_rms']=float(raw.detach().square().mean().sqrt())
    if epsilon==0:
        result['tensor_error']=compare_carter_after_training(model,xv,gauge)
    if hasattr(model,'reconstruct'):
        result['hessian_error']=float((vmap(model.reconstruct)(xv[:8])-vmap(model.tensor)(xv[:8])).abs().max().detach())
    k=vmap(model.tensor)(xv).detach()
    d=vmap(gauge.momentum_scale)(xv)
    result['component_rms_coordinate']=k.square().mean(0).sqrt().tolist()
    result['component_rms_weighted']=(k*d[:,:,None]*d[:,None,:]).square().mean(0).sqrt().tolist()
    return result


def run_case(args,eps):
    folder=args.out/f'epsilon_{eps:g}';folder.mkdir(parents=True,exist_ok=True)
    g=Geometry(epsilon=eps)
    x,p,xv,pv,train,heldout=dataset(g,args.stage,folder)
    results=[]
    for seed in args.seeds:
        seed_dir=folder/f'seed_{seed}';seed_dir.mkdir(exist_ok=True)
        torch.manual_seed(seed)
        gauge=NeuralInvariant(g)
        def evaluate(label,model,training=None):
            print(f'Verify epsilon={eps:g} seed={seed} {label}',flush=True)
            r=measure(model,x,p,xv,pv,heldout,gauge,eps)
            r.update({'label':label,'seed':seed,'epsilon':eps,'training':training})
            if hasattr(model,'state_dict'):
                torch.save({'geometry':asdict(g),'width':24,
                            'normalized_inputs':getattr(model,'normalized_inputs',False),
                            'output_scaling':getattr(model,'output_scaling','local'),
                            'state_dict':model.state_dict()},seed_dir/f'{label}.pt')
            fn=model.tensor_function() if hasattr(model,'tensor_function') else model.tensor
            iv=invariant_values(g,heldout[0],fn)['Q']
            np.savez_compressed(seed_dir/f'{label}_orbit.npz',tau=heldout[0]['tau'],invariant=iv)
            save_json(seed_dir/f'{label}.json',r)
            results.append(r)
            print(f'  residual={r["killing"]["frame_relative_rms"]:.3e}; drift={r["heldout_max_drift"]:.3e}',flush=True)
            return r
        # Baseline fitting is repeated per seed for complete independent records,
        # but shares fixed data; equal baseline results are expected.
        baseline=QuadraticInvariant(g);bfit=fit(baseline,x,p)
        evaluate('baseline',GaugedCandidate(baseline,gauge),bfit)
        torch.save({'geometry':asdict(g),'state_dict':baseline.state_dict()},seed_dir/'baseline.pt')
        if eps==0:
            evaluate('carter_reference',GaugedCandidate(CarterReference(g),gauge))
            evaluate('random_symmetric',GaugedCandidate(RandomTensor(g,seed+700),gauge))
            torch.manual_seed(seed);untrained=NeuralInvariant(g,output_scaling=args.output_scaling)
            evaluate('untrained',untrained)
        variants=['full']
        if eps==0:
            variants=['before','cons_only','full']
            if args.stage=='development': variants=['before','normalization_only','cons_only','full']
        if getattr(args,'variants',None):
            variants=args.variants
        for variant in variants:
            torch.manual_seed(seed)
            if variant=='before':
                model=LegacyNeural(g)
            else:
                model=NeuralInvariant(g,output_scaling=args.output_scaling if variant!='normalization_only' else 'local')
            print(f'Train epsilon={eps:g}, seed={seed}, variant={variant}',flush=True)
            if variant in ['before','normalization_only']:
                training=train_neural(model,x,p,steps=3000,lbfgs_steps=1000,seed=seed+4000)
            else:
                def callback(m):
                    # Save only. Verification after training, with no feedback to optimizer.
                    torch.save(copy.deepcopy(m.state_dict()),seed_dir/f'{variant}_adam_state.pt')
                training,adam_state=optimize(model,x,p,steps=args.steps,
                                            lbfgs_steps=args.lbfgs_steps,seed=seed+4000,
                                            geometry_loss=variant=='full',callback=callback)
                adam_model=NeuralInvariant(g,output_scaling=model.output_scaling);adam_model.load_state_dict(adam_state)
                evaluate(variant+'_adam',adam_model,{'optimizer':'Adam endpoint; paired with full L-BFGS run'})
                evaluate(variant+'_lbfgs',model,copy.deepcopy(training))
                training['head_polish']=polish_output_layer(model,x,p,geometry_loss=variant=='full',rcond=1e-8)
                with torch.no_grad():
                    c,k=physical_terms(model,PhysicsBatch(model,x,p))
                dc,dk=training['denominators']
                training['history'].append({'stage':'head_svd','step':args.steps+training['lbfgs_iterations']+1,
                    'conservation':float(c),'killing':float(k),'nontriviality':0.,'regularization':0.,
                    'weighted_conservation':float(c)/dc,'weighted_killing':float(k)/dk if variant=='full' else 0.,
                    'total':float(c)/dc+(float(k)/dk if variant=='full' else 0.)})
                training['final_conservation']=float(c);training['final_killing']=float(k)
            evaluate(variant,model,training)
        save_json(folder/'results.json',results)
    return results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=Path('final_results'))
    parser.add_argument('--stage',choices=['development','final'],default='final')
    parser.add_argument('--seeds',type=int,nargs='+',default=[0,1,2])
    parser.add_argument('--eps',type=float,nargs='+',default=[0,.01,.02,.05,.1])
    parser.add_argument('--variants',nargs='+',choices=['before','normalization_only','cons_only','full'],help='Development-only ablation subset')
    parser.add_argument('--output-scaling',choices=['local','fixed'],default='local')
    parser.add_argument('--steps',type=int,default=1500)
    parser.add_argument('--lbfgs-steps',type=int,default=1500)
    args=parser.parse_args()
    if args.stage=='final' and args.variants:
        parser.error('Final suite must include all specified ablations')
    if args.out.exists() and any(args.out.iterdir()):
        parser.error('Use an empty/new output folder to preserve previous experiments')
    if any(abs(e)>.5 for e in args.eps) or args.steps<0 or args.lbfgs_steps<0:
        parser.error('Invalid epsilon or optimizer budget')
    args.out.mkdir(parents=True,exist_ok=True)
    torch.set_default_dtype(torch.float64);torch.set_num_threads(1)
    configuration=vars(args).copy();configuration['out']=str(args.out)
    configuration['notes']='Fixed shared data across initializations; no final-test model selection.'
    save_json(args.out/'configuration.json',configuration)
    start=time.perf_counter();rows=[]
    for eps in args.eps:
        rows+=run_case(args,eps)
        save_json(args.out/'results.json',rows)
    save_json(args.out/'runtime.json',{'seconds':time.perf_counter()-start})
    if args.stage=='final' and set(args.seeds)=={0,1,2} and set(args.eps)=={0,.01,.02,.05,.1}:
        from .final_reporting import build
        build(args.out,['.'])
    print('Completed:',args.out,flush=True)


if __name__=='__main__': main()
