"""Symbolic exactness checks for the frozen SYMMETRIA-AI experiment.

This module does **not** claim an exact Killing tensor for the learned neural
candidate.  It provides a narrow symbolic statement that is directly relevant
to the deformation experiment: the Kerr rank-2 Killing tensor, when carried
unchanged into the toy deformed metric, ceases to satisfy the Killing equation
for every non-zero epsilon.

The proof is constructive.  At the exact audit point
    M=1, a=3/5, r=8, theta=pi/3,
one symmetrized covariant Killing-residual component is derived exactly as

    R_{t r phi} = 277127271 / 84753091804160 * epsilon.

A tensor that were Killing on the full spacetime would have every residual
component vanish at every point; this non-zero exact component therefore rules
out the *unchanged Kerr tensor* as an exact Killing tensor for epsilon != 0.
It does not rule out a different epsilon-dependent Killing tensor.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def derive_fixed_kerr_component():
    """Return an exact SymPy expression for R_(t r phi) at the audit point.

    The target metric is the full deformed metric.  The tensor itself is the
    epsilon=0 Carter/Kerr tensor and is not refit or corrected with epsilon.
    Derivatives with respect to r and theta are taken before evaluating the
    exact audit point.
    """
    import sympy as sp

    r, th, eps = sp.symbols("r th epsilon", real=True)
    a = sp.Rational(3, 5)
    s, c = sp.sin(th), sp.cos(th)
    s2, c2 = s**2, c**2
    sigma = r**2 + a**2 * c2
    delta = r**2 - 2*r + a**2
    h_tt = r**-2 * sp.Rational(1, 2) * (3*c2 - 1)

    gtt0 = -(1 - 2*r/sigma)
    gtp = -2*a*r*s2/sigma
    gpp = (r**2 + a**2 + 2*a**2*r*s2/sigma) * s2
    grr = sigma/delta
    gth = sigma
    g0 = sp.Matrix([
        [gtt0, 0, 0, gtp],
        [0, grr, 0, 0],
        [0, 0, gth, 0],
        [gtp, 0, 0, gpp],
    ])
    h = sp.zeros(4)
    h[0, 0] = h_tt
    gexpr = g0 + eps*h
    Dexpr = sp.diag(-a*a*c2, 0, 1, c2/s2)

    point = {r: sp.Integer(8), th: sp.pi/3}
    g0p = sp.simplify(g0.subs(point))
    gp = sp.simplify(gexpr.subs(point))
    gi0p = sp.simplify(g0p.inv())
    gip = sp.simplify(gp.inv())

    z4 = sp.zeros(4)
    dg0 = [z4, sp.simplify(g0.diff(r).subs(point)),
           sp.simplify(g0.diff(th).subs(point)), z4]
    dh = [z4, sp.simplify(h.diff(r).subs(point)),
          sp.simplify(h.diff(th).subs(point)), z4]
    dg = [sp.zeros(4), dg0[1] + eps*dh[1],
          dg0[2] + eps*dh[2], sp.zeros(4)]

    dgi0 = [sp.zeros(4),
            sp.simplify(-gi0p*dg0[1]*gi0p),
            sp.simplify(-gi0p*dg0[2]*gi0p),
            sp.zeros(4)]
    Dp = sp.simplify(Dexpr.subs(point))
    dD = [sp.zeros(4), sp.simplify(Dexpr.diff(r).subs(point)),
          sp.simplify(Dexpr.diff(th).subs(point)), sp.zeros(4)]
    c2p = sp.simplify(c2.subs(point))
    dc2 = [sp.Integer(0), sp.Integer(0),
           sp.simplify(sp.diff(c2, th).subs(point)), sp.Integer(0)]

    Kcon = sp.simplify(Dp - a*a*c2p*gi0p)
    dKcon = [
        sp.simplify(dD[q] - a*a*(dc2[q]*gi0p + c2p*dgi0[q]))
        for q in range(4)
    ]
    Kcov = sp.simplify(gp*Kcon*gp)
    dKcov = [
        sp.simplify(dg[q]*Kcon*gp + gp*dKcon[q]*gp + gp*Kcon*dg[q])
        for q in range(4)
    ]

    Gamma = [[[
        sp.cancel(sum(
            gip[ell, d] * (
                dg[aa][d, bb] + dg[bb][d, aa] - dg[d][aa, bb]
            ) for d in range(4)
        ) / 2)
        for bb in range(4)] for aa in range(4)] for ell in range(4)]

    def nabla(aa, bb, cc):
        value = dKcov[aa][bb, cc]
        for ell in range(4):
            value -= (Gamma[ell][aa][bb]*Kcov[ell, cc]
                      + Gamma[ell][aa][cc]*Kcov[bb, ell])
        return sp.cancel(value)

    # Symmetrization convention is the same as geometry.killing_residual:
    # (nabla_a K_bc + nabla_b K_ca + nabla_c K_ab) / 3.
    aa, bb, cc = 0, 1, 3  # t, r, phi
    residual = sp.factor(sp.cancel(
        (nabla(aa, bb, cc) + nabla(bb, cc, aa) + nabla(cc, aa, bb)) / 3
    ))
    return eps, residual


def audit_report():
    import sympy as sp

    eps, residual = derive_fixed_kerr_component()
    expected = sp.Rational(277127271, 84753091804160) * eps
    exact_match = bool(sp.simplify(residual - expected) == 0)
    return {
        "scope": "fixed Kerr tensor carried unchanged into the toy deformed metric",
        "claim": (
            "For the experiment's M=1, a=0.6 geometry, the unchanged Kerr "
            "tensor is not an exact Killing tensor for any epsilon != 0."
        ),
        "audit_point": {"M": "1", "a": "3/5", "r": "8", "theta": "pi/3"},
        "residual_component": "R_(t r phi)",
        "exact_expression": str(residual),
        "factorized_expected": "277127271*epsilon/84753091804160",
        "exact_match": exact_match,
        "logical_status": (
            "exact local disproof for the unchanged Kerr tensor when epsilon != 0; "
            "not a non-existence proof for other epsilon-dependent Killing tensors"
        ),
        "learned_candidate_status": (
            "finite-domain numerical verification only; no exact symbolic "
            "certification is claimed for the neural candidate"
        ),
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, default=Path("results/exactness_audit.json"))
    args = p.parse_args()
    report = audit_report()
    if not report["exact_match"]:
        raise RuntimeError("Symbolic derivation did not match the audited exact factor.")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report, indent=2) + "\n")
    print("Wrote symbolic exactness audit:", args.out)
    print(report["residual_component"], "=", report["exact_expression"])


if __name__ == "__main__":
    main()
