"""Conservation training only; independent Killing verification is held out."""
import time
import torch
from torch.func import jacrev, vmap


def flow_data(geometry,x,p):
    dx,dp=vmap(geometry.flow)(x,p)
    s=torch.stack((p[:,0],p[:,1],p[:,2]/x[:,1],
                   p[:,3]/(x[:,1]*x[:,2].sin())),dim=1).norm(dim=1).clamp_min(.1)
    return dx.detach(),dp.detach(),s.detach()


def conservation_residual(model,x,p,flow=None):
    """Exact instantaneous dI/dlambda, divided by positive momentum scale^3."""
    if flow is None:
        flow=flow_data(model.geometry,x,p)
    dx,dp,s=flow
    fn=model.tensor_function() if hasattr(model,'tensor_function') else model.tensor
    k=vmap(fn)(x)
    dk=vmap(jacrev(fn))(x)
    raw=(torch.einsum('nijk,ni,nj,nk->n',dk,p,p,dx)
         +2*torch.einsum('nij,ni,nj->n',k,p,dp))
    return raw,raw/s**3


def train_neural(model,x,p,steps=400,batch_size=128,lr=.002,seed=8101,lbfgs_steps=40):
    """Adam mini-batches followed by training-only full-batch L-BFGS.

    Fixed budget; no held-out data, Carter labels, or baseline coefficients.
    The gauge fixes scale and removes known trivial invariant combinations.
    """
    start=time.perf_counter()
    initial_norm=model.gauge()[1]
    if not bool(torch.isfinite(initial_norm)) or float(initial_norm.detach()) <= 1e-10:
        raise ValueError("Degenerate neural candidate: zero/trivial gauge norm")
    flow=flow_data(model.geometry,x,p)
    optimizer=torch.optim.Adam(model.parameters(),lr=lr)
    rng=torch.Generator().manual_seed(seed)
    history=[]
    with torch.no_grad():
        initial=float(conservation_residual(model,x,p,flow)[1].square().mean())
    for step in range(steps):
        ids=torch.randperm(len(x),generator=rng)[:min(batch_size,len(x))]
        optimizer.zero_grad()
        raw,res=conservation_residual(model,x[ids],p[ids],tuple(v[ids] for v in flow))
        loss=res.square().mean()
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError('Nonfinite neural conservation loss')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),10.)
        optimizer.step()
        if step%50==0 or step==steps-1:
            history.append({'step':step+1,'batch_loss':float(loss.detach())})
            print(f'  neural Adam {step+1}/{steps}: {float(loss.detach()):.3e}',flush=True)
    evaluations=0
    if lbfgs_steps:
        optimizer=torch.optim.LBFGS(model.parameters(),lr=.8,max_iter=lbfgs_steps,
                                    tolerance_grad=1e-12,tolerance_change=1e-15,
                                    line_search_fn='strong_wolfe')
        def closure():
            nonlocal evaluations
            optimizer.zero_grad()
            loss=conservation_residual(model,x,p,flow)[1].square().mean()
            loss.backward()
            evaluations+=1
            return loss
        optimizer.step(closure)
    with torch.no_grad():
        raw,res=conservation_residual(model,x,p,flow)
        final_norm=model.gauge()[1]
        if not bool(torch.isfinite(final_norm)) or float(final_norm) <= 1e-10:
            raise ValueError("Degenerate neural candidate: zero/trivial gauge norm")
        if not bool(torch.isfinite(res).all()):
            raise FloatingPointError("Nonfinite final conservation residual")
    return {'initial_loss':initial,'final_loss':float(res.square().mean()),
            'raw_conservation_rms':float(raw.square().mean().sqrt()),
            'adam_steps':steps,'lbfgs_max_iter':lbfgs_steps,'lbfgs_evaluations':evaluations,
            'batch_size':batch_size,'lr':lr,'seed':seed,'history':history,
            'seconds':time.perf_counter()-start,'samples':len(x),
            'parameters':sum(p.numel() for p in model.parameters())}
