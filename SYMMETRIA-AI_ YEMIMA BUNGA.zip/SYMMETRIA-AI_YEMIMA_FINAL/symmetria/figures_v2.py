"""Publication-oriented figures for matched SYMMETRIA-AI verification."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import numpy as np


def _read(path):
    with Path(path).open(newline="") as f:
        return list(csv.DictReader(f))


def make_kerr_benchmark(kerr_csv, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = _read(kerr_csv)
    metrics = [("tensor_error", "Tensor error"), ("R_K", r"$R_K$"), ("delta_I", r"$\delta I$")]
    fig, ax = plt.subplots(figsize=(6.2, 4.0), layout="constrained")
    xs = np.arange(len(metrics), dtype=float)
    for i, (key, _) in enumerate(metrics):
        vals = np.array([float(r[key]) for r in rows])
        jitter = np.linspace(-.055, .055, len(vals)) if len(vals) > 1 else np.array([0.])
        line, = ax.plot([xs[i]-.12, xs[i]+.12], [np.median(vals)]*2, linewidth=2)
        ax.scatter(np.full(len(vals), xs[i]) + jitter, vals, s=24, alpha=.55, color=line.get_color())
    ax.set_yscale("log")
    ax.set_xticks(xs, [label for _, label in metrics])
    ax.set_ylabel("Dimensionless diagnostic")
    ax.grid(axis="y", alpha=.16)
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)


def make_deformation_response(sweep_csv, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = _read(sweep_csv)
    eps = sorted({float(r["epsilon"]) for r in rows})
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.0), layout="constrained")
    for ax, key, ylabel in zip(
        axes, ["R_K", "delta_I"],
        [r"Residu Killing relatif $R_K$", r"Drift invarian maksimum $\delta I$"]
    ):
        medians = []
        seed_x, seed_y = [], []
        for e in eps:
            vals = np.array([float(r[key]) for r in rows
                             if r["method"] == "SYMMETRIA_AI" and float(r["epsilon"]) == e])
            medians.append(np.median(vals))
            jitter = np.linspace(-.0008, .0008, len(vals)) if e == 0 else np.linspace(-.0012, .0012, len(vals))
            seed_x.extend((np.full(len(vals), e) + jitter).tolist())
            seed_y.extend(vals.tolist())
        ai_line, = ax.plot(eps, medians, marker="o", linewidth=1.35, label="Median SYMMETRIA-AI")
        ax.scatter(seed_x, seed_y, s=19, alpha=.38, color=ai_line.get_color(), label="Seed individual")
        fixed = [float(next(r[key] for r in rows
                            if r["method"] == "FIXED_KERR" and float(r["epsilon"]) == e))
                 for e in eps]
        ax.plot(eps, fixed, marker="s", linestyle="--", linewidth=1.3, label="Tensor Kerr tetap")
        ax.set_yscale("log")
        ax.set_xlabel(r"Parameter deformasi $\epsilon$")
        ax.set_ylabel(ylabel)
        ax.set_xticks(eps)
        ax.grid(alpha=.16)
    for ax in axes:
        ax.legend(fontsize=8, loc="lower right")
    fig.savefig(out, dpi=300, bbox_inches="tight")
    plt.close(fig)



def _sci_tex(value):
    if value == 0:
        return r"$0$"
    exponent = int(np.floor(np.log10(abs(value))))
    coefficient = value / (10**exponent)
    return rf"${coefficient:.2f}\times10^{{{exponent}}}$"


def make_kerr_table(kerr_csv, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = _read(kerr_csv)
    rows = sorted(rows, key=lambda row: int(row["seed"]))
    specs = [("tensor_error", "Galat tensor"), ("R_K", r"$R_K$"), ("delta_I", r"$\delta I$")]
    body = []
    for key, label in specs:
        vals = [float(row[key]) for row in rows]
        body.append([label] + [_sci_tex(v) for v in vals] + [_sci_tex(float(np.median(vals)))])
    columns = ["Besaran"] + [f"Seed {int(row['seed'])}" for row in rows] + ["Median"]
    fig, ax = plt.subplots(figsize=(9.0, 2.2))
    ax.axis("off")
    table = ax.table(cellText=body, colLabels=columns, cellLoc="center", colLoc="center", loc="center")
    table.auto_set_font_size(False)
    table.set_fontsize(10.5)
    table.scale(1, 1.55)
    for (row, col), cell in table.get_celld().items():
        cell.set_linewidth(.65)
        if row == 0:
            cell.set_text_props(weight="bold")
        elif col == 0:
            cell.set_text_props(ha="left")
        elif col == len(columns)-1:
            cell.set_text_props(weight="bold")
    fig.savefig(out, dpi=300, bbox_inches="tight", pad_inches=.08)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--results", type=Path, default=Path("results"))
    p.add_argument("--out", type=Path, default=Path("figures"))
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    make_kerr_benchmark(args.results/"kerr_benchmark.csv", args.out/"Kerr_Benchmark.png")
    make_kerr_table(args.results/"kerr_benchmark.csv", args.out/"Table_2_4_1_Kerr_Benchmark.png")
    make_deformation_response(args.results/"deformation_sweep.csv", args.out/"Figure_2_4_1_Deformation_Response.png")
    print("Wrote figures to", args.out)


if __name__ == "__main__":
    main()
