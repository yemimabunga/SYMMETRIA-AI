"""Neural symmetric tensor; no Carter features, labels, or baseline warm start."""
import torch
from torch import nn
from torch.func import jacrev, vmap
from .geodesics import collocation


class NeuralInvariant(nn.Module):
    """Stationary/axisymmetric MLP with a finite-probe nontriviality gauge.

    Project out span(g^-1, dt^2, sym(dt dphi), dphi^2), then fix the
    weighted RMS tensor norm on fixed gauge points. This gauge is a model
    restriction, not a proof of independence outside those points.
    """
    def __init__(self, geometry, width=24, gauge_points=48, gauge_seed=7301):
        super().__init__()
        self.geometry = geometry
        self.width = width
        self.gauge_seed = gauge_seed
        self.net = nn.Sequential(nn.Linear(2,width), nn.Tanh(),
                                 nn.Linear(width,width), nn.Tanh(), nn.Linear(width,10)).double()
        basis=[]
        for i in range(4):
            for j in range(i,4):
                b=torch.zeros(4,4,dtype=torch.float64)
                b[i,j]=b[j,i]=1.
                basis.append(b)
        self.register_buffer('symmetric_basis',torch.stack(basis))
        x,_=collocation(gauge_points,gauge_seed,geometry.mass)
        self.register_buffer('gauge_x',x)
        trivial=vmap(self.trivial_tensors)(x).detach()
        scale=vmap(self.momentum_scale)(x)
        weight=scale[:,:,None]*scale[:,None,:]
        design=(trivial*weight[:,None]).permute(0,2,3,1).reshape(-1,4)
        # Column normalization prevents g^-1 being swamped by angular products.
        column_scale=design.square().sum(0).sqrt()
        pinv=torch.linalg.pinv(design/column_scale)/column_scale[:,None]
        self.register_buffer('gauge_trivial',trivial)
        self.register_buffer('gauge_weight',weight)
        self.register_buffer('gauge_pinv',pinv)

    def momentum_scale(self,x):
        one=x[1]*0+1
        return torch.stack((one,one,x[1],x[1]*x[2].sin()))

    def trivial_tensors(self,x):
        zero=x[1]*0
        tt=torch.diag(torch.stack((zero+1,zero,zero,zero)))
        pp=torch.diag(torch.stack((zero,zero,zero,zero+1)))
        tp=torch.zeros_like(tt)
        # Constant tensors are independent of x; tensor construction stays vmap-safe.
        cross=torch.tensor([[0.,0.,0.,1.],[0.,0.,0.,0.],
                            [0.,0.,0.,0.],[1.,0.,0.,0.]],dtype=x.dtype,device=x.device)
        return torch.stack((self.geometry.inverse(x),tt,cross,pp))

    def raw_tensor(self,x):
        inputs=torch.stack(((x[1]/self.geometry.mass-10.)/4.,(x[2]-torch.pi/2)))
        packed=self.net(inputs)
        scaled=torch.einsum('b,bij->ij',packed,self.symmetric_basis)
        d=self.momentum_scale(x)
        return scaled/(d[:,None]*d[None,:])

    def gauge(self):
        raw=vmap(self.raw_tensor)(self.gauge_x)
        coefficients=self.gauge_pinv@(raw*self.gauge_weight).reshape(-1)
        residual=raw-torch.einsum('b,nbij->nij',coefficients,self.gauge_trivial)
        norm=(residual*self.gauge_weight).square().mean().sqrt().clamp_min(1e-12)
        return coefficients,norm

    def tensor_function(self):
        coefficients,norm=self.gauge()
        def tensor(x):
            return (self.raw_tensor(x)-torch.einsum('b,bij->ij',coefficients,self.trivial_tensors(x)))/norm
        return tensor

    def tensor(self,x):
        return self.tensor_function()(x)

    def forward(self,x,p):
        return p@self.tensor(x)@p

    def reconstruct(self,x,p=None):
        if p is None:
            p=torch.zeros_like(x)
        return .5*jacrev(jacrev(lambda q:self(x,q)))(p)
