"""Boyer–Lindquist coordinates x=(t,r,theta,phi), signature (-+++).

All derivatives are automatic derivatives in float64. No Carter formula is
used in Hamilton's equations or in the learner.
"""
from dataclasses import dataclass
import torch
from torch.func import jacrev


@dataclass(frozen=True)
class Geometry:
    mass: float = 1.0
    spin: float = 0.6
    epsilon: float = 0.0

    def __post_init__(self):
        if self.mass <= 0 or abs(self.spin) >= self.mass:
            raise ValueError("Require M > 0 and |a| < M (subextremal Kerr).")
        if abs(self.epsilon) > 0.5:
            raise ValueError("Toy deformation restricted to |epsilon| <= 0.5.")

    @property
    def cutoff(self):
        # This is a numerical boundary, NOT a deformed event-horizon claim.
        return self.mass + (self.mass**2 - self.spin**2)**0.5 + 0.4*self.mass

    def covariant(self, x):
        r, th = x[1], x[2]
        m, a = self.mass, self.spin
        s2, c2 = th.sin()**2, th.cos()**2
        sigma = r*r + a*a*c2
        delta = r*r - 2*m*r + a*a
        z = r*0
        # Controlled, stationary/axisymmetric toy deformation g + eps*h.
        # The radial envelope is intentionally appreciable at r ~ 6..14 M.
        # This is not claimed to solve the Einstein field equations.
        h_tt = (m/r)**2 * (0.5*(3*c2-1))
        gtt = -(1-2*m*r/sigma) + self.epsilon*h_tt
        gtp = -2*m*a*r*s2/sigma
        gpp = (r*r+a*a+2*m*a*a*r*s2/sigma)*s2
        return torch.stack((torch.stack((gtt,z,z,gtp)),
                            torch.stack((z,sigma/delta,z,z)),
                            torch.stack((z,z,sigma,z)),
                            torch.stack((gtp,z,z,gpp))))

    def inverse(self, x):
        return torch.linalg.inv(self.covariant(x))

    def hamiltonian(self, x, p):
        return 0.5 * p @ self.inverse(x) @ p

    def flow(self, x, p):
        gi = self.inverse(x)
        dgi = jacrev(self.inverse)(x)  # dgi[i,j,k] = partial_k g^{ij}
        return gi @ p, -0.5*torch.einsum("ijk,i,j->k", dgi, p, p)


def carter_tensor(geometry, x):
    """Contravariant K_Q, valid as a Killing tensor only for epsilon=0.

    Q = p_theta² + cos²(theta)[a²(mu²-E²)+Lz²/sin²(theta)],
    with mu²=-2H, so this tensor is defined OFF the mass shell as well.
    K_Q differs from the common K by -(Lz-aE)² (a trivial invariant).
    """
    a, th = geometry.spin, x[2]
    c2 = th.cos()**2
    diag = torch.stack((-a*a*c2, th*0, th*0+1, c2/th.sin()**2))
    return torch.diag(diag) - a*a*c2*geometry.inverse(x)


def christoffel(geometry, x):
    gi = geometry.inverse(x)
    dg = jacrev(geometry.covariant)(x)
    return 0.5*(torch.einsum("ld,dba->lab", gi, dg)
                + torch.einsum("ld,dab->lab", gi, dg)
                - torch.einsum("ld,abd->lab", gi, dg))


def killing_residual(geometry, tensor_fn, x):
    """Return R_abc = nabla_(a K_bc), symmetrized with factor 1/3."""
    def lowered(y):
        g = geometry.covariant(y)
        return g @ tensor_fn(y) @ g
    k = lowered(x)
    dk = jacrev(lowered)(x)
    gamma = christoffel(geometry, x)
    nabla = (dk.permute(2,0,1)
             - torch.einsum("lab,lc->abc", gamma, k)
             - torch.einsum("lac,bl->abc", gamma, k))
    return (nabla+nabla.permute(1,2,0)+nabla.permute(2,0,1))/3


def local_frame(geometry, x):
    """ZAMO orthonormal frame e[A,mu] outside the numerical boundary."""
    g, gi = geometry.covariant(x), geometry.inverse(x)
    alpha = (-gi[0,0]).rsqrt()
    omega = -g[0,3]/g[3,3]
    z = x[0]*0
    return torch.stack((torch.stack((1/alpha,z,z,omega/alpha)),
                        torch.stack((z,g[1,1].rsqrt(),z,z)),
                        torch.stack((z,z,g[2,2].rsqrt(),z)),
                        torch.stack((z,z,z,g[3,3].rsqrt()))))
