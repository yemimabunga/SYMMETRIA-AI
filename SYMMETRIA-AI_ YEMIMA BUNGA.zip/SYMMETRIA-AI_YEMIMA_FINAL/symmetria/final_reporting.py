"""Build figures and tables exclusively from saved experiment measurements."""
import json
from pathlib import Path
import numpy as np


def metric(row,key):
    return row['killing']['frame_relative_rms'] if key=='killing' else row[key]


def stats(rows,label,eps,key):
    values=[metric(r,key) for r in rows if r['label']==label and r['epsilon']==eps]
    a=np.array(values,dtype=float)
    return float(a.mean()),float(a.std(ddof=1)) if len(a)>1 else 0.


def cell(pair): return f'{pair[0]:.3e} ± {pair[1]:.2e}'


def build(root,folders,selected='full'):
    root=Path(root);rows=[]
    for folder in folders:
        rows.extend(json.loads((root/folder/'results.json').read_text()))
    seen={(r['epsilon'],r['seed'],r['label']) for r in rows}
    if len(seen)!=len(rows): raise ValueError('Duplicate experiment rows')
    for eps in [0,.01,.02,.05,.1]:
        for label in ['baseline',selected]:
            seeds={r['seed'] for r in rows if r['epsilon']==eps and r['label']==label}
            if seeds!={0,1,2}: raise ValueError(f'Missing seeds for {eps} {label}: {seeds}')
    report={'selected_label':selected,'source_folders':folders,'rows':rows,
            'statistics':'arithmetic mean and sample standard deviation, ddof=1; model seeds 0,1,2; shared data'}
    (root/'FINAL_METRICS.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    metrics=[('Tensor error Kerr','tensor_error'),('Relative Killing residual','killing'),('Held-out invariant drift','heldout_max_drift')]
    lines=['# FINAL RESULTS — SYMMETRIA-AI','',
           'All numbers below were computed, not inserted as targets. Statistics are mean ± sample standard deviation for seeds 0, 1, 2 on shared, independent final verification data.','',
           '## A. What was actually demonstrated','',
           'The symmetric neural tensor, quadratic invariant, Hessian reconstruction, independent geometric verification, and controlled deformation pipeline run end-to-end without Carter training labels. Baseline physics is unchanged.','',
           '### Controlled BEFORE vs AFTER','',
           'Both recipes are rerun on the same final training and verification data; this is not a comparison between different held-out datasets. BEFORE is the preserved old neural recipe. AFTER is the frozen selected recipe.','',
           '| Metric | Before | After | Baseline | Ratio of means before/after |',
           '|---|---:|---:|---:|---:|']
    for title,key in metrics:
        b,a,base=stats(rows,'before',0,key),stats(rows,selected,0,key),stats(rows,'baseline',0,key)
        lines.append(f'| {title} | {cell(b)} | {cell(a)} | {cell(base)} | {b[0]/max(a[0],1e-30):.2f}× |')
    lines+=['','Ratios below 1 indicate regression, not improvement. Tensor comparison removes known trivial tensors and fixes norm and sign. Drift is max|I−I₀|/max(1,|I₀|), not automatically a percentage.','',
            '### Every seed — no best-seed selection','',
            '| Seed | Recipe | Tensor error | Killing residual | Held-out drift |',
            '|---:|---|---:|---:|---:|']
    for seed in [0,1,2]:
        for label in ['before',selected]:
            r=next(r for r in rows if r['seed']==seed and r['epsilon']==0 and r['label']==label)
            lines.append(f'| {seed} | {label} | {r["tensor_error"]:.3e} | {metric(r,"killing"):.3e} | {r["heldout_max_drift"]:.3e} |')
    lines+=['','### Negative controls and ablations','',
            '| Candidate | Tensor error | Killing residual | Held-out drift |',
            '|---|---:|---:|---:|']
    for label in ['random_symmetric','untrained','before','cons_only_adam','cons_only_lbfgs','cons_only','full_adam','full_lbfgs','full','baseline','carter_reference']:
        lines.append(f'| {label} | {cell(stats(rows,label,0,"tensor_error"))} | {cell(stats(rows,label,0,"killing"))} | {cell(stats(rows,label,0,"heldout_max_drift"))} |')
    lines+=['','Adam endpoints and Adam+L-BFGS endpoints share the same initialization and data. The conservation-only and full variants use the same architecture, data, and optimizer budgets; full adds the geometric loss. Carter is only an evaluation reference.','',
            '### Deformation sweep','',
            '| ε | Candidate | Train conservation RMS | Verification conservation RMS | Killing residual | Held-out drift |',
            '|---:|---|---:|---:|---:|---:|']
    for eps in [0,.01,.02,.05,.1]:
        for label in ['baseline',selected]:
            values=[cell(stats(rows,label,eps,key)) for key in ['training_conservation_rms','conservation_balanced_rms','killing','heldout_max_drift']]
            lines.append(f'| {eps:.2f} | {label} | '+ ' | '.join(values)+' |')
    lines+=['',
            '## B. What remains unproven / future work','',
            '- This is finite-domain numerical evidence, not a global/symbolic proof of a Killing tensor.',
            '- No automatic exact/approximate/broken classification is introduced. Failure does not prove hidden symmetry does not exist.',
            '- The three seeds vary initialization and optimizer sampling on shared data. They are not three independent dataset populations.',
            '- Deformation trends smaller than neural error and seed scatter cannot be identified as physical effects from these runs.',
            '- The tensor is restricted to stationary, axisymmetric, quadratic invariants. The projection gauge is defined on 48 fixed points.',
            '- No chaos, Lyapunov, resonance, Poincaré, adaptive sampling, or tetrad-network feature is claimed.',
            '- Orbit selection deliberately restricts the experiment to complete segments inside r/M∈[6,14], θ∈[0.65,π−0.65]; conclusions do not extend to rejected/out-of-domain orbits.',
            '- Toy deformation is not a validated solution of Einstein field equations.',
            '', 'See ../AUDIT.md for recovery provenance and comparison to archived reference results.','']
    (root/'FINAL_RESULTS.md').write_text('\n'.join(lines))
    interpret(root,rows,selected)
    ground_truth(root,folders,lines)
    plot(root,rows,selected)
    plot_invariants(root,folders,selected)
    return rows


def plot(root,rows,selected):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    plots=root/'final_plots';plots.mkdir(exist_ok=True)
    eps=np.array([0,.01,.02,.05,.1])
    for key,name,title in [('killing','epsilon_killing.png','Relative Killing residual'),
                           ('heldout_max_drift','epsilon_drift.png','Maximum held-out invariant drift'),
                           ('conservation_balanced_rms','epsilon_conservation.png','Independent conservation RMS')]:
        fig,ax=plt.subplots(figsize=(7.5,4.8),layout='constrained')
        for label,color in [('baseline','#236b8e'),(selected,'#b24b40')]:
            means=[]
            for seed in [0,1,2]:
                y=[metric(next(r for r in rows if r['label']==label and r['seed']==seed and r['epsilon']==e),key) for e in eps]
                ax.semilogy(eps,np.maximum(y,1e-19),'-',color=color,alpha=.25)
            means=[stats(rows,label,e,key)[0] for e in eps]
            ax.semilogy(eps,means,'o-',color=color,label=f'{label}: mean (thin lines = each seed)')
        ax.set(xlabel=r'Deformation $\epsilon$',ylabel=title,title=title+' | seeds 0, 1, 2')
        ax.grid(alpha=.2);ax.legend(fontsize=8)
        fig.savefig(plots/name,dpi=180);plt.close(fig)
    labels=['random_symmetric','untrained','before','cons_only_adam','cons_only_lbfgs','cons_only','full_adam','full_lbfgs','full','baseline','carter_reference']
    fig,axes=plt.subplots(1,2,figsize=(13,5.5),layout='constrained')
    for ax,key,title in zip(axes,['killing','heldout_max_drift'],['Independent Killing residual','Held-out invariant drift']):
        y=[stats(rows,label,0,key)[0] for label in labels]
        ax.bar(range(len(labels)),np.maximum(y,1e-19),color=['#bdbdbd']*3+['#dfa85e']*3+['#b24b40']*3+['#236b8e']*2)
        for seed in [0,1,2]:
            values=[metric(next(r for r in rows if r['label']==l and r['epsilon']==0 and r['seed']==seed),key) for l in labels]
            ax.scatter(range(len(labels)),np.maximum(values,1e-19),s=12,color='black',alpha=.5)
        ax.set_yscale('log');ax.set_xticks(range(len(labels)),labels,rotation=55,ha='right')
        ax.set_title(title);ax.grid(axis='y',alpha=.2)
    fig.suptitle('Kerr ablations | bars = mean; dots = every seed')
    fig.savefig(plots/'baseline_vs_optimized.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
    for seed,ax in enumerate(axes):
        row=next(r for r in rows if r['label']==selected and r['epsilon']==0 and r['seed']==seed)
        h=row['training']['history']
        adam=row['training']['adam_steps']
        x=[v['step']+(adam if v['stage']=='lbfgs' else 0) for v in h]
        for key in ['weighted_conservation','weighted_killing','total']:
            y=[v[key] for v in h]
            if max(y)>0: ax.semilogy(x,np.maximum(y,1e-30),label=key)
        ax.axvline(adam,color='gray',ls=':',label='Adam → L-BFGS')
        ax.set(title=f'Seed {seed}',xlabel='Optimizer steps',ylabel='Loss on fixed initial scale')
        ax.grid(alpha=.2)
    axes[0].legend(fontsize=7)
    fig.suptitle('Loss balance | last point = output refinement; soft penalties = 0')
    fig.savefig(plots/'loss_curves.png',dpi=180);plt.close(fig)
    # Raw physical terms are plotted separately to avoid hiding initial scales.
    fig,axes=plt.subplots(1,3,figsize=(15,4.2),layout='constrained')
    for seed,ax in enumerate(axes):
        row=next(r for r in rows if r['label']==selected and r['epsilon']==0 and r['seed']==seed)
        h=row['training']['history'];adam=row['training']['adam_steps']
        x=[v['step']+(adam if v['stage']=='lbfgs' else 0) for v in h]
        for key in ['conservation','killing']: ax.semilogy(x,[v[key] for v in h],label=key)
        ax.set(title=f'Seed {seed}',xlabel='Optimizer steps',ylabel='Unweighted physical loss');ax.legend()
    fig.savefig(plots/'loss_curves_raw.png',dpi=180);plt.close(fig)


def ground_truth(root,folders,lines):
    import torch
    from .geometry import Geometry,carter_tensor
    from .geodesics import invariant_values,drift
    torch.set_default_dtype(torch.float64)
    results={}
    for eps in [0,.01,.02,.05,.1]:
        folder=next(root/f/f'epsilon_{eps:g}' for f in folders if (root/f/f'epsilon_{eps:g}/data.npz').exists())
        data=np.load(folder/'data.npz');g=Geometry(epsilon=eps)
        entries=[]
        for i in range(4):
            o={'states':data[f'heldout_{i}'],'tau':data[f'heldout_tau_{i}']}
            values=invariant_values(g,o,lambda z:carter_tensor(g,z))
            entries.append({k:drift(v) for k,v in values.items()})
        results[str(eps)]=entries
    (root/'GROUND_TRUTH_DIAGNOSTICS.json').write_text(json.dumps({'kerr':results['0'],'deformed_carter_form_comparison':{k:v for k,v in results.items() if k!='0'},'note':'Q at nonzero epsilon is a Kerr-form diagnostic, not a conserved ground truth.'},indent=2)+'\n')
    path=root/'FINAL_RESULTS.md'
    text=path.read_text()
    table=['### Ground-truth diagnostics on held-out Kerr orbits','',
           '| Quantity | Maximum drift |','|---|---:|']
    for k in ['E','Lz','H','Q']:
        table.append(f'| {k} | {max(o[k] for o in results["0"]):.4e} |')
    # JSON string of float zero is 0.0 in the direct loop below; support both.
    text=text.replace('## B. What remains unproven / future work','\n'.join(table)+'\n\n## B. What remains unproven / future work')
    path.write_text(text)


def plot_invariants(root,folders,selected):
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for ax,eps in zip(axes,[0,.1]):
        for label,color in [('baseline','#236b8e'),(selected,'#b24b40')]:
            for seed in [0,1,2]:
                p=next(root/f/f'epsilon_{eps:g}'/f'seed_{seed}'/f'{label}_orbit.npz' for f in folders if (root/f/f'epsilon_{eps:g}'/f'seed_{seed}'/f'{label}_orbit.npz').exists())
                d=np.load(p);v=d['invariant']
                ax.plot(d['tau'],(v-v[0])/max(1.,abs(v[0])),color=color,alpha=.65,
                        label=label if seed==0 else None)
        ax.set(title=rf'$\epsilon={eps:g}$ | all three seeds',xlabel=r'Affine parameter $\lambda/M$',ylabel=r'$(I-I_0)/\max(1,|I_0|)$')
        ax.legend();ax.grid(alpha=.2)
    fig.savefig(root/'final_plots/invariant_evolution.png',dpi=180);plt.close(fig)


def interpret(root,rows,selected):
    lines=['### What helped, and what did not','']
    for key,title in [('killing','Killing residual'),('heldout_max_drift','held-out drift')]:
        before=stats(rows,'before',0,key)[0]
        after=stats(rows,selected,0,key)[0]
        lbfgs=stats(rows,selected+'_lbfgs',0,key)[0]
        cons=stats(rows,'cons_only',0,key)[0]
        lines.append(f'- {title}: controlled old-recipe / final mean ratio = {before/after:.2f}×. Paired pre-head-refinement / post-refinement mean ratio = {lbfgs/after:.2f}×. Conservation-only / full mean ratio = {cons/after:.2f}×.')
    for seed in [0,1,2]:
        cons=next(r for r in rows if r['epsilon']==0 and r['seed']==seed and r['label']=='cons_only')
        full=next(r for r in rows if r['epsilon']==0 and r['seed']==seed and r['label']==selected)
        improvements=[key for key in ['tensor_error','killing','heldout_max_drift'] if metric(full,key)<metric(cons,key)]
        lines.append(f'- Seed {seed}: full improves over conservation-only on: '+(', '.join(improvements) if improvements else 'none of the three tracked metrics')+'. All other metrics for this seed are unchanged or worse.')
    lines+=['','The most direct attribution is the paired output-layer refinement comparison: hidden weights and data are fixed during that step. Before/after compares a complete recipe change, not one isolated factor. Initial-loss normalization, optimizer settings, and geometry constraints are not all independently isolated on every seed.','',
            'The full recipe was selected before inspecting final seeds. It is not replaced after seeing an ablation perform better on a particular seed. Three seeds are limited evidence, not a population-level guarantee.','']
    path=root/'FINAL_RESULTS.md';text=path.read_text()
    path.write_text(text.replace('## B. What remains unproven / future work','\n'.join(lines)+'\n## B. What remains unproven / future work'))
