"""Regression tests against analytical identities and independent differences."""
import unittest
import numpy as np
import torch
from torch.func import jacrev,vmap
from symmetria.geometry import Geometry,carter_tensor,killing_residual,local_frame
from symmetria.geodesics import collocation,initial_state,integrate,invariant_values,drift
from symmetria.baseline_model import QuadraticInvariant,fit
from symmetria.diagnostics import tensor_diagnostics,carter_error

torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


class PhysicsTests(unittest.TestCase):
    def setUp(self):
        self.g=Geometry()
        self.x=torch.tensor([0.,8.,1.1,0.])
        self.p=torch.tensor([-0.95,0.08,1.2,3.1])

    def test_metric_signature_inverse_and_schwarzschild_limit(self):
        for eps in [0.,0.1,0.3,-0.3]:
            geo=Geometry(epsilon=eps)
            x,_=collocation(32,11)
            g=vmap(geo.covariant)(x)
            torch.testing.assert_close(g@vmap(geo.inverse)(x),torch.eye(4).expand(32,4,4))
            eigen=torch.linalg.eigvalsh(g)
            self.assertTrue(bool((eigen[:,0]<0).all() and (eigen[:,1:]>0).all()))
        g=Geometry(spin=0).covariant(self.x)
        expected=torch.diag(torch.tensor([-(1-2/8),1/(1-2/8),64,64*np.sin(1.1)**2]))
        torch.testing.assert_close(g,expected)

    def test_flow_matches_finite_difference_hamiltonian(self):
        dx,dp=self.g.flow(self.x,self.p)
        step=1e-5
        for k in range(4):
            d=torch.eye(4)[k]*step
            dHx=(self.g.hamiltonian(self.x+d,self.p)-self.g.hamiltonian(self.x-d,self.p))/(2*step)
            dHp=(self.g.hamiltonian(self.x,self.p+d)-self.g.hamiltonian(self.x,self.p-d))/(2*step)
            self.assertAlmostEqual(float(dp[k]),-float(dHx),places=9)
            self.assertAlmostEqual(float(dx[k]),float(dHp),places=9)

    def test_carter_off_shell_and_residual_identity(self):
        # A direct scalar formula with mu²=-2H checks tensor convention.
        x,p=self.x,self.p
        k=lambda z:carter_tensor(self.g,z)
        mu2=-2*self.g.hamiltonian(x,p)
        q=p[2]**2+x[2].cos()**2*(self.g.spin**2*(mu2-p[0]**2)+p[3]**2/x[2].sin()**2)
        torch.testing.assert_close(p@k(x)@p,q)
        for fn in [k,self.g.inverse]:
            r=killing_residual(self.g,fn,x)
            self.assertLess(float(r.abs().max()),1e-10)
        # Non-Killing control checks signs/index placements with a nonzero RHS.
        bad=lambda z:z[1]*k(z)
        invariant=lambda z,q:q@bad(z)@q
        dx,dp=self.g.flow(x,p)
        dI=jacrev(invariant,0)(x,p)@dx+jacrev(invariant,1)(x,p)@dp
        r=killing_residual(self.g,bad,x)
        contraction=torch.einsum("abc,a,b,c",r,dx,dx,dx)
        self.assertGreater(abs(float(dI)),1e-5)
        torch.testing.assert_close(dI,contraction,rtol=1e-10,atol=1e-10)

    def test_frame_is_orthonormal(self):
        e=local_frame(self.g,self.x)
        torch.testing.assert_close(e@self.g.covariant(self.x)@e.T,torch.diag(torch.tensor([-1.,1.,1.,1.])))

    def test_discovery_without_carter_labels(self):
        x,p=collocation(512,42)
        model=QuadraticInvariant(self.g)
        result=fit(model,x,p)
        xv,_=collocation(64,43)
        self.assertEqual(result["rank"],result["free_parameters"])
        self.assertLess(result["final_loss"],1e-20)
        self.assertLess(carter_error(model,xv),1e-8)
        torch.testing.assert_close(model.reconstruct(self.x),model.tensor(self.x))
        diag=tensor_diagnostics(self.g,model.tensor,xv)
        self.assertLess(diag["frame_relative_rms"],1e-9)

    def test_deformation_detected_by_independent_residual(self):
        geo=Geometry(epsilon=0.3)
        x,p=collocation(256,45)
        model=QuadraticInvariant(geo)
        fit(model,x,p)
        xv,_=collocation(64,46)
        diag=tensor_diagnostics(geo,model.tensor,xv)
        self.assertGreater(diag["frame_relative_rms"],1e-7)

    def test_orbit_conservation_and_tolerance_refinement(self):
        y0=initial_state(self.g,np.random.default_rng(42))
        self.assertAlmostEqual(float(self.g.hamiltonian(torch.tensor(y0[:4]),torch.tensor(y0[4:]))),-0.5,places=12)
        errors=[]
        for tol in [1e-7,1e-11]:
            orbit=integrate(self.g,y0,duration=70,samples=70,rtol=tol,atol=tol*0.01)
            values=invariant_values(self.g,orbit,lambda x:carter_tensor(self.g,x))
            errors.append(max(drift(values["H"]),drift(values["Q"])))
            self.assertLess(drift(values["E"]),1e-13)
            self.assertLess(drift(values["Lz"]),1e-13)
        self.assertLess(errors[1],1e-8)
        self.assertLessEqual(errors[1],max(errors[0]*2,1e-12))


if __name__ == "__main__":
    unittest.main()
