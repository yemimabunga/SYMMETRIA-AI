"""Architecture, independent geometry identities, and portable CLI regression tests."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
import torch
from torch.func import jacrev

from symmetria.ai_model import NeuralInvariant
from symmetria.diagnostics import comparison_metrics
from symmetria.geodesics import collocation, initial_state, integrate
from symmetria.geometry import Geometry, christoffel


torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


class ProtocolTests(unittest.TestCase):
    def test_final_architecture_output_shape_and_seed_reproducibility(self):
        torch.manual_seed(7)
        first = NeuralInvariant(Geometry())
        torch.manual_seed(7)
        second = NeuralInvariant(Geometry())
        self.assertEqual(first.net(torch.zeros(2)).shape, (10,))
        self.assertEqual(sum(p.numel() for p in first.parameters()), 922)
        self.assertTrue(all(p.dtype == torch.float64 for p in first.parameters()))
        for a, b in zip(first.parameters(), second.parameters()):
            torch.testing.assert_close(a, b, rtol=0, atol=0)
        x, p = collocation(12, 19)
        xx, pp = collocation(12, 19)
        torch.testing.assert_close(x, xx, rtol=0, atol=0)
        torch.testing.assert_close(p, pp, rtol=0, atol=0)
        different, _ = collocation(12, 20)
        self.assertFalse(torch.equal(x, different))

    def test_christoffel_against_schwarzschild_analytic_components(self):
        g = Geometry(spin=0)
        x = torch.tensor([0., 8., 1.1, 0.])
        r, th = x[1], x[2]
        gamma = christoffel(g, x)
        torch.testing.assert_close(gamma[1, 0, 0], (1-2/r)/r**2)
        torch.testing.assert_close(gamma[0, 0, 1], 1/(r*r*(1-2/r)))
        torch.testing.assert_close(gamma[1, 2, 2], -(r-2))
        torch.testing.assert_close(gamma[2, 3, 3], -th.sin()*th.cos())
        torch.testing.assert_close(gamma, gamma.transpose(1, 2))

    def test_lowering_and_metric_compatibility_in_deformed_geometry(self):
        g = Geometry(epsilon=.1)
        x = torch.tensor([0., 9., 1.3, .2])
        cov, inv = g.covariant(x), g.inverse(x)
        upper = torch.arange(16.).reshape(4, 4)
        upper = (upper + upper.T)/2
        lower = cov @ upper @ cov
        torch.testing.assert_close(inv @ lower @ inv, upper)
        gamma = christoffel(g, x)
        dg = jacrev(g.covariant)(x)
        derivative = (dg.permute(2, 0, 1)
                      - torch.einsum('lab,lc->abc', gamma, cov)
                      - torch.einsum('lac,bl->abc', gamma, cov))
        torch.testing.assert_close(derivative, torch.zeros_like(derivative), atol=1e-12, rtol=0)

    def test_heldout_diagnostics_do_not_update_candidate(self):
        torch.manual_seed(9)
        model = NeuralInvariant(Geometry())
        state = {k: v.clone() for k, v in model.state_dict().items()}
        x, p = collocation(6, 64000)
        y = initial_state(model.geometry, np.random.default_rng(62000))
        orbit = integrate(model.geometry, y, duration=2., samples=12)
        result = comparison_metrics(model, x, p, [orbit])
        self.assertTrue(np.isfinite(result['heldout_max_drift']))
        self.assertTrue(np.isfinite(result['killing']['frame_relative_rms']))
        for key, value in model.state_dict().items():
            torch.testing.assert_close(value, state[key], rtol=0, atol=0)

    def test_benchmark_cli_executes_and_keeps_training_verification_separate(self):
        # A small-budget integration test exercises the real pipeline, not the
        # scientific performance claim. The release benchmark uses full budgets.
        project = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)/'run'
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
            command = [sys.executable, '-m', 'symmetria.final_benchmark',
                       '--stage', 'development', '--eps', '.01', '--seeds', '0',
                       '--variants', 'full', '--steps', '0', '--lbfgs-steps', '0',
                       '--out', str(out)]
            run = subprocess.run(command, cwd=project, env=env, capture_output=True, text=True, timeout=180)
            self.assertEqual(run.returncode, 0, run.stderr + run.stdout[-2000:])
            rows = json.loads((out/'results.json').read_text())
            self.assertEqual({r['label'] for r in rows}, {'baseline', 'full_adam', 'full_lbfgs', 'full'})
            data = np.load(out/'epsilon_0.01'/'data.npz')
            self.assertEqual(data['train_x'].shape, (1008, 4))
            self.assertEqual(data['verify_x'].shape, (512, 4))
            train = set(map(tuple, np.column_stack([data['train_x'], data['train_p']])))
            verify = set(map(tuple, np.column_stack([data['verify_x'], data['verify_p']])))
            self.assertFalse(train & verify)
            starts = {tuple(data[f'train_{i}'][0]) for i in range(6)}
            heldout = {tuple(data[f'heldout_{i}'][0]) for i in range(4)}
            self.assertFalse(starts & heldout)
            # Existing runs are protected instead of silently overwritten.
            repeat = subprocess.run(command, cwd=project, env=env, capture_output=True, text=True, timeout=30)
            self.assertNotEqual(repeat.returncode, 0)
            self.assertIn('empty/new output folder', repeat.stderr)


if __name__ == '__main__':
    unittest.main()
