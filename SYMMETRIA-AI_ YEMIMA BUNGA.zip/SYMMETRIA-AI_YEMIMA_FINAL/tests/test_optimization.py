import unittest
import torch
from torch.func import jacrev,vmap
from symmetria.geometry import Geometry,killing_residual,local_frame
from symmetria.ai_model import NeuralInvariant
from symmetria.geodesics import collocation
from symmetria.optimization import PhysicsBatch,cached_tensor,frame_residual,optimize,diverse_orbits,polish_output_layer,physical_terms

torch.set_default_dtype(torch.float64);torch.set_num_threads(1)

class OptimizationTests(unittest.TestCase):
    def test_cached_operator_matches_independent_covariant_operator(self):
        torch.manual_seed(14)
        g=Geometry(epsilon=.1);m=NeuralInvariant(g,width=8,output_scaling='fixed')
        x,p=collocation(8,71);batch=PhysicsBatch(m,x,p)
        k,dk=cached_tensor(m,batch)
        torch.testing.assert_close(k,vmap(m.tensor)(x),rtol=1e-11,atol=1e-11)
        torch.testing.assert_close(dk,vmap(jacrev(m.tensor))(x),rtol=1e-10,atol=1e-10)
        actual=frame_residual(k,dk,batch)
        rc=vmap(lambda z:killing_residual(g,m.tensor,z))(x)
        e=vmap(lambda z:local_frame(g,z))(x)
        expected=torch.einsum('nai,nbj,nck,nijk->nabc',e,e,e,rc)
        torch.testing.assert_close(actual,expected,rtol=1e-9,atol=1e-10)

    def test_normalization_chain_rule_and_double_precision(self):
        m=NeuralInvariant(Geometry(),width=8,output_scaling='fixed')
        x,p=collocation(2,82);h=1e-5
        derivative=jacrev(m.raw_tensor)(x[0])
        for j in [1,2]:
            d=torch.eye(4)[j]*h
            numeric=(m.raw_tensor(x[0]+d)-m.raw_tensor(x[0]-d))/(2*h)
            torch.testing.assert_close(numeric,derivative[:,:,j],rtol=1e-6,atol=1e-8)
        self.assertTrue(all(t.dtype==torch.float64 for t in m.parameters()))
        self.assertEqual(derivative.dtype,torch.float64)

    def test_balanced_geometry_optimization_is_finite(self):
        torch.manual_seed(42);m=NeuralInvariant(Geometry(),width=8)
        x,p=collocation(32,80)
        log,state=optimize(m,x,p,steps=3,lbfgs_steps=4)
        self.assertLess(log['history'][-1]['total'],log['history'][0]['total'])
        self.assertAlmostEqual(log['history'][0]['total'],2.,places=10)
        self.assertEqual(log['history'][-1]['nontriviality'],0.)

    def test_linear_head_refinement_is_unsupervised_and_preserves_hidden_weights(self):
        torch.manual_seed(14)
        m=NeuralInvariant(Geometry(),width=6)
        x,p=collocation(40,198)
        b=PhysicsBatch(m,x,p)
        before=physical_terms(m,b)
        denominators=[float(v.detach()) for v in before]
        hidden=[v.detach().clone() for v in m.net[:-1].parameters()]
        result=polish_output_layer(m,x,p,denominators=denominators)
        after=physical_terms(m,b)
        self.assertLess(sum(float(v.detach())/d for v,d in zip(after,denominators)),2.)
        for old,new in zip(hidden,m.net[:-1].parameters()):
            torch.testing.assert_close(old,new)
        self.assertGreater(result['retained_rank'],0)
        self.assertTrue(torch.isfinite(m.tensor(x[0])).all())

    def test_diverse_sampling_preserves_mass_shell(self):
        g=Geometry()
        orbits=diverse_orbits(g,3,19,duration=2.)
        for o in orbits:
            y=torch.tensor(o['states'][0])
            self.assertAlmostEqual(float(g.hamiltonian(y[:4],y[4:])), -.5,places=11)
        starts=[o['states'][0][1] for o in orbits]
        self.assertGreater(max(starts)-min(starts),1.)

if __name__=='__main__': unittest.main()
