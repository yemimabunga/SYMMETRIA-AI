"""Structural and differential tests, without requiring neural Carter recovery."""
import unittest
import torch
from torch.func import vmap,jacrev
from symmetria.ai_model import NeuralInvariant
from symmetria.geometry import Geometry,killing_residual
from symmetria.geodesics import collocation
from symmetria.training import train_neural,conservation_residual
from symmetria.diagnostics import GaugedCandidate

torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


class NeuralTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(123)
        self.g=Geometry()
        self.model=NeuralInvariant(self.g,width=12)
        self.x,self.p=collocation(64,72)

    def test_symmetry_quadratic_and_hessian(self):
        x,p=self.x[0],self.p[0]
        k=self.model.tensor(x)
        torch.testing.assert_close(k,k.T)
        torch.testing.assert_close(self.model(x,2*p),4*self.model(x,p))
        torch.testing.assert_close(self.model.reconstruct(x,p),k)

    def test_nonzero_normalization_and_trivial_projection(self):
        m=self.model
        k=vmap(m.tensor)(m.gauge_x)
        weighted=k*m.gauge_weight
        torch.testing.assert_close(weighted.square().mean(),torch.tensor(1.))
        trivial=(m.gauge_trivial*m.gauge_weight[:,None]).permute(0,2,3,1).reshape(-1,4)
        trivial=trivial/trivial.norm(dim=0)
        torch.testing.assert_close(trivial.T@weighted.reshape(-1),torch.zeros(4),atol=1e-10,rtol=0)

    def test_projection_removes_added_trivial_invariants(self):
        m=self.model
        class Shifted:
            geometry=m.geometry
            def tensor(self,x):
                return m.tensor(x)+2*m.geometry.inverse(x)+3*m.trivial_tensors(x)[1]
        shifted=GaugedCandidate(Shifted(),m)
        torch.testing.assert_close(vmap(shifted.tensor)(self.x[:8]),vmap(m.tensor)(self.x[:8]),atol=1e-10,rtol=1e-10)

    def test_conservation_matches_geometric_residual_and_finite_difference(self):
        x,p=self.x[0],self.p[0]
        dx,dp=self.g.flow(x,p)
        raw,_=conservation_residual(self.model,x[None],p[None])
        r=killing_residual(self.g,self.model.tensor,x)
        torch.testing.assert_close(raw[0],torch.einsum('abc,a,b,c',r,dx,dx,dx),rtol=1e-9,atol=1e-9)
        h=1e-6
        numeric=(self.model(x+h*dx,p+h*dp)-self.model(x-h*dx,p-h*dp))/(2*h)
        torch.testing.assert_close(raw[0],numeric,rtol=1e-6,atol=1e-7)

    def test_training_has_finite_gradients_and_reduces_loss(self):
        r=train_neural(self.model,self.x,self.p,steps=20,lbfgs_steps=5,batch_size=64)
        self.assertLess(r['final_loss'],r['initial_loss'])
        for p in self.model.parameters():
            self.assertTrue(bool(torch.isfinite(p).all()))
        xv,pv=collocation(24,73)
        self.assertTrue(bool(torch.isfinite(conservation_residual(self.model,xv,pv)[0]).all()))

    def test_zero_candidate_is_rejected(self):
        with torch.no_grad():
            for p in self.model.parameters():
                p.zero_()
        with self.assertRaisesRegex(ValueError,"Degenerate"):
            train_neural(self.model,self.x,self.p,steps=0,lbfgs_steps=0)

    def test_checkpoint_roundtrip(self):
        other=NeuralInvariant(self.g,width=12)
        other.load_state_dict(self.model.state_dict())
        torch.testing.assert_close(other.tensor(self.x[0]),self.model.tensor(self.x[0]))


if __name__=='__main__':
    unittest.main()
