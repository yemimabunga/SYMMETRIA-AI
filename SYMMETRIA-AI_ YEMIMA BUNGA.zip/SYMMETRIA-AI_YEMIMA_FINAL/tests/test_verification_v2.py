"""Regression tests for the matched deformation-verification protocol."""
import unittest
import numpy as np
import torch

from symmetria.geodesics import matched_orbits
from symmetria.geometry import Geometry
from symmetria.verification_v2 import FixedKerrTensor


torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


class VerificationV2Tests(unittest.TestCase):
    def test_matched_orbits_share_skeleton_and_mass_shell(self):
        eps = [0., .1]
        geometries = [Geometry(epsilon=e) for e in eps]
        data = matched_orbits(geometries, count=2, seed=991, duration=2., samples=12)
        self.assertEqual(data['skeletons'].shape, (2, 7))
        self.assertEqual(len(data['orbits']), 2)
        for orbit_index in range(2):
            spatial_reference = None
            for geometry, group in zip(geometries, data['orbits']):
                start = group[orbit_index]['states'][0]
                skeleton = data['skeletons'][orbit_index]
                np.testing.assert_allclose(start[:4], skeleton[:4], rtol=0, atol=0)
                np.testing.assert_allclose(start[5:], skeleton[4:], rtol=0, atol=0)
                spatial = np.r_[start[:4], start[5:]]
                if spatial_reference is None:
                    spatial_reference = spatial
                else:
                    np.testing.assert_allclose(spatial, spatial_reference, rtol=0, atol=0)
                y = torch.tensor(start)
                self.assertAlmostEqual(float(geometry.hamiltonian(y[:4], y[4:])), -.5, places=10)
                self.assertGreater(float((geometry.inverse(y[:4]) @ y[4:])[0]), 0.)

    def test_fixed_kerr_tensor_is_identical_across_evaluation_geometries(self):
        x = torch.tensor([0., 9., 1.2, .3])
        a = FixedKerrTensor(Geometry(epsilon=0.)).tensor(x)
        b = FixedKerrTensor(Geometry(epsilon=.1)).tensor(x)
        torch.testing.assert_close(a, b, rtol=0, atol=0)


if __name__ == '__main__':
    unittest.main()
