"""Exact symbolic checks for the fixed-Kerr comparator audit."""
import unittest
from fractions import Fraction

import torch

from symmetria.exactness_audit import derive_fixed_kerr_component
from symmetria.geometry import Geometry, killing_residual
from symmetria.verification_v2 import FixedKerrTensor


torch.set_default_dtype(torch.float64)
torch.set_num_threads(1)


class ExactnessAuditTests(unittest.TestCase):
    def test_exact_fixed_kerr_breakdown_component(self):
        import sympy as sp
        eps, residual = derive_fixed_kerr_component()
        expected = sp.Rational(277127271, 84753091804160) * eps
        self.assertEqual(sp.simplify(residual - expected), 0)
        self.assertEqual(sp.simplify(residual.subs(eps, 0)), 0)
        self.assertNotEqual(sp.simplify(residual.subs(eps, sp.Rational(1, 10))), 0)

    def test_symbolic_component_matches_torch_residual(self):
        eps = 0.1
        x = torch.tensor([0., 8., torch.pi/3, 0.])
        geo = Geometry(epsilon=eps)
        fixed = FixedKerrTensor(geo)
        numeric = killing_residual(geo, fixed.tensor, x)[0, 1, 3].item()
        exact = float(Fraction(277127271, 84753091804160)) * eps
        self.assertAlmostEqual(numeric, exact, places=14)


if __name__ == "__main__":
    unittest.main()
