# SYMMETRIA-AI

**Geometry-constrained neural discovery and verification of Carter-like hidden-symmetry candidates in deformed Kerr geodesics.**

SYMMETRIA-AI searches for a symmetric rank-2 contravariant tensor
`K^{mu nu}(r, theta)` whose quadratic form `I = K^{mu nu} p_mu p_nu`
is conserved along geodesics and whose lowered tensor approximately satisfies
the Killing equation. Carter's constant is **not** used as a training label.

The scientific logic is:

**AI proposes -> general relativity verifies -> humans interpret.**

## What is frozen

The submitted model uses:

- MLP `2 -> 24 -> 24 -> 10`, `tanh`, 922 parameters, `float64`;
- normalized `(r, theta)` as network inputs;
- ten independent components of a symmetric `K^{mu nu}` as outputs;
- conservation and Killing residual losses normalized to their initial values;
- a hard gauge projection/normalization to remove trivial invariants and the zero solution;
- 1500 Adam steps, up to 1500 L-BFGS iterations, then unsupervised SVD output-head refinement;
- six training geodesics and 768 off-shell training probes;
- epsilon grid `{0, 0.01, 0.02, 0.05, 0.10}`;
- model seeds `0, 1, 2`, with every seed retained.

The core training recipe was **not changed after inspecting the deformation results**.

## Primary verification protocol

The final submission uses the matched verification protocol in
`symmetria/verification_v2.py`.

- **8 matched held-out orbit families** are used at every epsilon.
- Each family keeps the same `(t,r,theta,phi,p_r,p_theta,p_phi)` skeleton;
  only `p_t` is re-solved from the target metric's unit-mass timelike mass shell.
- An orbit family is accepted only if its full segment remains in the common
  numerical domain for every epsilon. Model performance is never used for selection.
- **512 common verification points** are used for every epsilon.
- The same analytical Kerr tensor from epsilon=0 is carried unchanged into the
  deformed metrics as a **fixed Kerr comparator**. It is never refit or optimized.

Two diagnostics are reported:

- `R_K`: relative orthonormal-frame RMS of `nabla_(alpha K_beta gamma)`;
- `delta_I`: maximum `|I_i-I_0| / max(1,|I_0|)` over the matched held-out orbits.

At epsilon=0, the learned tensor is additionally aligned with and compared against
the known Kerr/Carter tensor through `tensor_error`.

## Exact symbolic audit

`python -m symmetria.exactness_audit` performs a separate symbolic check of the
**fixed Kerr comparator**. For the experiment's `M=1`, `a=0.6`, at the exact point
`r=8`, `theta=pi/3`, SymPy derives

`R_(t r phi) = (277127271 / 84753091804160) * epsilon`.

Therefore the unchanged Kerr tensor is **provably not an exact Killing tensor** of
this toy deformed metric for any non-zero epsilon. This is an exact statement about
the unchanged Kerr tensor only; it is **not** a proof that no other epsilon-dependent
Killing tensor exists.

The learned neural candidates remain finite-domain numerical candidates. This package
does not claim global symbolic certification for them.

## Results included

Primary outputs are in `results/`:

- `kerr_benchmark.csv` — per-seed epsilon=0 tensor error, `R_K`, and `delta_I`;
- `deformation_sweep.csv` — all AI seeds plus the fixed Kerr comparator;
- `final_summary.csv` — mean, sample SD, median, minimum, and maximum;
- `comparison_summary.csv` — fixed-Kerr / AI-median comparison ratios;
- `exactness_audit.json` — symbolic comparator audit;
- `matched_verification_data.npz` and `verification_manifest.json` — reproducibility data.

Publication-oriented figures are in `figures/`.

For the essay, the primary deformation figure is:

`figures/Figure_2_4_1_Deformation_Response.png`

The Kerr benchmark is provided as `figures/Table_2_4_1_Kerr_Benchmark.png` and
`results/kerr_benchmark.csv`; `figures/Kerr_Benchmark.png` is retained as a
supplementary visualization.

## Reproduce the submitted verification

Python >= 3.10 is required.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
```

Run tests:

```bash
python -m unittest tests.test_verification_v2 tests.test_exactness_audit tests.test_neural tests.test_optimization -v
```

Re-run matched verification from the included frozen checkpoints into a new folder:

```bash
python -m symmetria.verification_v2 --source checkpoints --out verification_rerun
python -m symmetria.figures_v2 --results verification_rerun --out figures_rerun
python -m symmetria.exactness_audit --out verification_rerun/exactness_audit.json
```

Existing result folders are not silently overwritten.

## Scientific scope

Supported by the submitted experiment:

1. At epsilon=0, the learned candidates approach the known Kerr tensor and have low
   Killing residual and held-out invariant drift.
2. The unchanged Kerr tensor ceases to be an exact Killing tensor for epsilon != 0;
   this comparator breakdown is also certified symbolically at an exact audit point.
3. On the matched finite domain, re-learned SYMMETRIA-AI candidates have substantially
   lower invariant drift than the fixed Kerr comparator for every non-zero epsilon.
4. The AI median Killing residual is below the fixed Kerr comparator for every tested
   non-zero epsilon, although individual-seed variation is visible at small deformation.

Not claimed:

- a global exact Killing tensor for the neural candidate;
- non-existence of a hidden symmetry when a search fails;
- exact/approximate/broken phase classification;
- chaos, resonance, or non-integrability from `R_K` or `delta_I` alone;
- physical realism of the toy deformation as a solution of Einstein's equations.

The deformation used here adds
`epsilon (M/r)^2 (3 cos^2(theta)-1)/2` to `g_tt`. It is a controlled toy ansatz,
not a validated astrophysical metric.

## Repository layout

```text
SYMMETRIA-AI_YEMIMA_FINAL/
├── README.md
├── LICENSE
├── CITATION.cff
├── FROZEN_PROTOCOL.json
├── requirements.txt
├── requirements-tested.txt
├── pyproject.toml
├── symmetria/          # source
├── tests/              # regression / physics tests
├── checkpoints/        # 15 frozen full checkpoints, 5 epsilon x 3 seeds
├── results/            # final matched-verification outputs
└── figures/            # publication-oriented figures
```
