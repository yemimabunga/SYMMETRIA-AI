# Results guide

The files in this directory are the final matched-verification outputs used for the submission.

- `kerr_benchmark.csv`: three frozen SYMMETRIA-AI seeds at epsilon=0.
- `deformation_sweep.csv`: every AI seed and the unchanged Kerr-tensor comparator at all five epsilon values.
- `final_summary.csv`: mean, sample SD, median, min, max, n.
- `comparison_summary.csv`: fixed-Kerr value divided by the AI median for each metric/epsilon.
- `exactness_audit.json`: exact symbolic audit of one Killing-residual component of the unchanged Kerr tensor.
- `matched_verification_data.npz`: the eight matched held-out orbit families.
- `verification_manifest.json`: the frozen evaluation construction.
- `detailed_metrics.json`: per-orbit and max diagnostics.

## Exact comparator statement

At M=1, a=3/5, r=8, theta=pi/3,

`R_(t r phi) = 277127271 * epsilon / 84753091804160`.

Thus the unchanged Kerr tensor is not an exact Killing tensor of the toy deformed metric for any epsilon != 0. This does **not** prove that no different epsilon-dependent Killing tensor exists.

## Learned candidate statement

The neural candidates are supported by finite-domain numerical residual and held-out-drift tests. No exact symbolic global Killing-tensor claim is made for the learned candidates.
